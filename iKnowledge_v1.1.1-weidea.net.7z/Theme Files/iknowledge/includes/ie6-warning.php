    <div id="ie6warning">
    	<div class="container">
        	<div class="inside">
                <h1><?php echo stripslashes(get_option($shortname.'_ie6_warning_title')); ?></h1>
                <p><?php echo stripslashes(get_option($shortname.'_ie6_warning_msg')); ?></p>
            </div>
        </div>
    </div>
</body>
</html>