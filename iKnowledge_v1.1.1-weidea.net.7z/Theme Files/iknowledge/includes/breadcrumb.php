<?php
if ( function_exists('yoast_breadcrumb') ) {
	echo '<div class="breadcrumb clearfix">';
	yoast_breadcrumb();
	echo '</div>';
}

if(function_exists('bcn_display')) {
	echo '<div class="breadcrumb clearfix">';
	bcn_display();
	echo '</div>';
}
?>