<?php
/**
 * Warrior Sticky Posts Widgets
 *
 * This file contains Latests Posts widget
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_sticky_posts_widget' );

// Register our widget
function warrior_sticky_posts_widget() {
	register_widget( 'Warrior_Sticky_Posts' );
}

// Warrior Sticky Posts Widget
class Warrior_Sticky_Posts extends WP_Widget {

	//  Setting up the widget
	function Warrior_Sticky_Posts() {
		$widget_ops  = array( 'classname' => 'warrior_sticky_posts', 'description' => __('Warrior Sticky Posts Widget', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_sticky_posts' );

		$this->WP_Widget( 'warrior_sticky_posts', __('Home: Warrior Sticky Posts', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		global $shortname;
		
		extract( $args );

		$warrior_sticky_posts_title    = apply_filters('widget_title', $instance['warrior_sticky_posts_title'] );
		$warrior_sticky_posts_total    = $instance['warrior_sticky_posts_total'];

		if ( is_home() ) {
		echo $before_widget;

		if($warrior_sticky_posts_title)
			echo $before_title . $warrior_sticky_posts_title . $after_title;
?>
		<div class="articles">
		<?php
         // Check the sticky post
		$sticky = get_option( 'sticky_posts' ); 
			
		if( !empty($sticky) ) :

            // Start fetching the posts from database
			$args = array(
				'posts_per_page' => $warrior_sticky_posts_total,
				'post__in'  => $sticky,
				'ignore_sticky_posts' => 1
			);
            $wp_query = new WP_Query( $args );
			if ( $wp_query->have_posts() ) : while($wp_query->have_posts()) : $wp_query->the_post();
        ?>
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<h4 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo warrior_post_title(60); ?></a></h4>
				<p class="categories">
					<span><?php _e('Categories', 'warrior'); ?></span>
					<?php the_category(', '); ?>
				</p>
			</div>
			<?php endwhile; endif; ?>
			<?php wp_reset_query(); ?>
        <?php else: ?>
            <p><?php _e('Sorry, no post found.', 'warrior'); ?></p>
        <?php endif; ?>
 		</div>
       
<?php
		echo $after_widget;
		}
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['warrior_sticky_posts_title']    = strip_tags( $new_instance['warrior_sticky_posts_title'] );
		$instance['warrior_sticky_posts_total']    = strip_tags( $new_instance['warrior_sticky_posts_total'] );

		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array('warrior_sticky_posts_title' => __('Featured Articles', 'warrior'), 'warrior_sticky_posts_total' => '6') );
	?>
		<p><?php _e('This widget will display all posts marked as sticky.', 'warrior'); ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'warrior_sticky_posts_title' ); ?>"><?php _e('Widget Title:', 'warrior'); ?></label>
            <input id="<?php echo $this->get_field_id( 'warrior_sticky_posts_title' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_sticky_posts_title' ); ?>" value="<?php echo $instance['warrior_sticky_posts_title']; ?>" />
        </p>
		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_sticky_posts_total' ); ?>"><?php _e('Number of Sticky Posts to be Displayed:', 'warrior'); ?></label>
			<input id="<?php echo $this->get_field_id( 'warrior_sticky_posts_total' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_sticky_posts_total' ); ?>" value="<?php echo $instance['warrior_sticky_posts_total']; ?>" />
		</p>
	<?php
	}
}
?>