<?php
/**
 * Warrior Categories Widgets
 *
 * This file contains custom categories widget
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_categories_widget' );

// Register our widget
function warrior_categories_widget() {
	register_widget( 'Warrior_Categories' );
}


/* Create new walker category, this is used to show description
 This walker will produce category list with h3 tag and add the category description
 result example :
 <li>
 	<h3>
		<a href="http://site.com/category-link">category name</a>
	</h3>
	here will be the description of the category
 </li>

*/
class Warrior_Category_Walker extends Walker_Category{
	function start_el(&$output, $category, $depth, $args) {
		extract($args);

		$cat_name = esc_attr( $category->name);
		$cat_name = apply_filters( 'list_cats', $cat_name, $category );
		$description  = esc_attr( strip_tags( apply_filters( 'category_description', $category->description, $category ) ) ) ; // get category description

		$before_name = '<h4 class="title">'; // wrap the category link with h3 tag
		$after_name = '</h4>';
		$link = '<a href="' . get_term_link( $category, $category->taxonomy ) . '" ';
		if ( $use_desc_for_title == 0 || empty($category->description) )
			$link .= 'title="' . sprintf(__( 'View all posts filed under %s', 'warrior' ), $cat_name) . '"';
		else
			$link .= 'title="' . esc_attr( strip_tags( apply_filters( 'category_description', $category->description, $category ) ) ) . '"';
		$link .= '>';
		$link .= $cat_name . '</a>';

		if ( isset($current_category) && $current_category )
			$_current_category = get_category( $current_category );

			$output .= "\t<li><span class=\"icon-file\"></span> $before_name$link$after_name <p>$description</p></li>\n";
	}
}

// Warrior Categories Widget
// Styling the unordered list with css class .warrior_cats
class Warrior_Categories extends WP_Widget {


	//  Setting up the widget
	function Warrior_Categories() {
		$widget_ops  = array( 'classname' => 'warrior_categories', 'description' => __('Warrior Categories Widget', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_categories' );

		$this->WP_Widget( 'warrior_categories', __('Home: Warrior Categories', 'warrior'), $widget_ops, $control_ops );
	}
	
	//  Widget
	function widget( $args, $instance ) {

		extract( $args );
		$warrior_categories_title        = apply_filters('widget_title', $instance['warrior_categories_title']);
		if (isset($instance['warrior_categories_list'])) {
			$include = implode(',', $instance['warrior_categories_list']);
		}else{
			$include = '';
		}

		if ( is_home() ) {
		echo $before_widget;
?>
		<?php echo $before_title . $warrior_categories_title . $after_title; ?>
		<ul class="warrior_cats">
		<?php  wp_list_categories(array('hierarchical' =>false, 'hide_empty' => 0 , 'orderby' => 'name', 'order' => 'ASC', 'title_li'=>'', 'include' => $include, 'walker' => new Warrior_Category_Walker() ) ); ?>
		</ul>
<?php
		echo $after_widget;
		}
	}

	//  Update widget option
	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['warrior_categories_title']     = strip_tags( $new_instance['warrior_categories_title'] );
		$instance['warrior_categories_list']     = $new_instance['warrior_categories_list'] ;
		return $instance;
	}

	//  Widget option form
	function form( $instance ) {
		$list = array();
		$instance = wp_parse_args( (array) $instance, array('warrior_categories_title' => __('Categories', 'warrior'), 'warrior_categories_list' => array() ) );
		if (  isset($instance['warrior_categories_list']) ) $list =  $instance['warrior_categories_list'];

	?>
        <p>
            <label for="<?php echo $this->get_field_id( 'warrior_categories_title' ); ?>"><?php _e('Widget Title:', 'warrior'); ?></label>
            <input id="<?php echo $this->get_field_id( 'warrior_categories_title' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_categories_title' ); ?>" value="<?php echo $instance['warrior_categories_title']; ?>" />
        </p>

		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_categories_list' ); ?>" style="display:block;"><?php _e('Categories:', 'warrior'); ?></label>
			<select id="<?php echo $this->get_field_id( 'warrior_categories_list' ); ?>" name="<?php echo $this->get_field_name( 'warrior_categories_list' ); ?>[]" multiple="multiple" style="height:100px" class="widefat" >
			<?php
				$categories = get_categories('hide_empty=0&orderby=name');
				foreach ($categories as $category_list ) { ?>
					<option value="<?php echo $category_list->cat_ID; ?>" <?php if ( array_search( $category_list->cat_ID, $list) !== false ) echo 'selected'; ?>><?php echo $category_list->cat_name; ?></option>
			<?php
				}
			?>
			</select>
		</p>
	<?php
	}
}
?>