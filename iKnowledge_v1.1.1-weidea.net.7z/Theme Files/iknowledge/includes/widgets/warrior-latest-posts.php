<?php
/**
 * Warrior Latest Posts Widgets
 *
 * This file contains Latests Posts widget
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_latest_posts_widget' );

// Register our widget
function warrior_latest_posts_widget() {
	register_widget( 'Warrior_Latest_Posts' );
}

// Warrior Latest Posts Widget
class Warrior_Latest_Posts extends WP_Widget {

	//  Setting up the widget
	function Warrior_Latest_Posts() {
		$widget_ops  = array( 'classname' => 'warrior_latest_posts', 'description' => __('Warrior Latest Posts Widget', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_latest_posts' );

		$this->WP_Widget( 'warrior_latest_posts', __('Home: Warrior Latest Posts', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		global $shortname;
		
		extract( $args );

		$warrior_latest_posts_title    = apply_filters('widget_title', $instance['warrior_latest_posts_title'] );
		$warrior_latest_posts_total    = $instance['warrior_latest_posts_total'];
		$warrior_latest_posts_category = $instance['warrior_latest_posts_category'];
		$warrior_latest_posts_categories = isset($warrior_latest_posts_category) ? $warrior_latest_posts_category : array();

		if ( is_home() ) {
		echo $before_widget;

		if($warrior_latest_posts_title)
			echo $before_title . $warrior_latest_posts_title . $after_title;
?>
		<div class="articles">
		<?php
            // Start fetching the posts from database
            $wp_query = new WP_Query("showposts=". $warrior_latest_posts_total ."&cat=". join(',',$warrior_latest_posts_categories) ."&ignore_sticky_posts=1");
            if ( $wp_query->have_posts() ) : while($wp_query->have_posts()) : $wp_query->the_post();
        ?>
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<h4 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo warrior_post_title(60); ?></a></h4>
				<p class="categories">
					<span><?php _e('Categories', 'warrior'); ?></span>
					<?php the_category(', '); ?>
				</p>
			</div>
		<?php endwhile; ?>
        <?php else: ?>
            <p><?php _e('Sorry, no post found.', 'warrior'); ?></p>
        <?php endif; ?>
        <?php wp_reset_query(); ?>
 		</div>
       
<?php
		echo $after_widget;
		}
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['warrior_latest_posts_title']    = strip_tags( $new_instance['warrior_latest_posts_title'] );
		$instance['warrior_latest_posts_total']    = strip_tags( $new_instance['warrior_latest_posts_total'] );
		$instance['warrior_latest_posts_category'] = $new_instance['warrior_latest_posts_category'];

		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array('warrior_latest_posts_title' => __('Recent Articles', 'warrior'), 'warrior_latest_posts_total' => '6', 'warrior_latest_posts_category' => array('')) );

		//Access the WordPress Categories via an Array
		$categories_array = array();  
		$categories_obj = get_categories('hierarchical=true&orderby=name');
		foreach ( $categories_obj as $category_obj ) {
			$categories_array[] = array('id' => $category_obj->cat_ID, 'name' => $category_obj->cat_name);
		}
	?>
        <p>
            <label for="<?php echo $this->get_field_id( 'warrior_latest_posts_title' ); ?>"><?php _e('Widget Title:', 'warrior'); ?></label>
            <input id="<?php echo $this->get_field_id( 'warrior_latest_posts_title' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_latest_posts_title' ); ?>" value="<?php echo $instance['warrior_latest_posts_title']; ?>" />
        </p>
		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_latest_posts_total' ); ?>"><?php _e('Number of Latest Posts to be Displayed:', 'warrior'); ?></label>
			<input id="<?php echo $this->get_field_id( 'warrior_latest_posts_total' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_latest_posts_total' ); ?>" value="<?php echo $instance['warrior_latest_posts_total']; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_latest_posts_category' ); ?>"><?php _e('Include this Category(s):', 'warrior'); ?></label>
			<select multiple="multiple" id="<?php echo $this->get_field_id( 'warrior_latest_posts_category' ); ?>" name="<?php echo $this->get_field_name( 'warrior_latest_posts_category' ); ?>[]" class="widefat" ><?php
			foreach ($categories_array as $category) {
				if ( in_array($category['id'], $instance['warrior_latest_posts_category']) !== false ) $selected = ' selected="selected"';
				else $selected = '';

				echo '<option'. $selected .' value="'.$category['id'].'">'.$category['name'].'</option>';
			}
			?></select>
			<small><?php _e('Hold the Shift key to select more than one.', 'warrior'); ?></small>
		</p>
	<?php
	}
}
?>