<?php
/**
 * Warrior Latest Video Widgets
 *
 * This file contains Latests Video widget
 * @copyright Copyright (c) 2010, Warrior
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_latest_video_widget' );

// Register our widget
function warrior_latest_video_widget() {
	register_widget( 'Warrior_Latest_video' );
}

// Warrior Latest Video Widget
class Warrior_Latest_Video extends WP_Widget {

	//  Setting up the widget
	function Warrior_Latest_Video() {
		$widget_ops  = array( 'classname' => 'warrior_latest_video', 'description' => __('Warrior Video Widget', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_latest_video', 'width' => '300' );

		$this->WP_Widget( 'warrior_latest_video', __('Warrior Video', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		global $shortname;
		
		extract( $args );

		$warrior_latest_video_title    = apply_filters('widget_title', $instance['warrior_latest_video_title'] );
		$warrior_latest_video_code    = $instance['warrior_latest_video_code'];
		$warrior_latest_video_desc = $instance['warrior_latest_video_desc'];

		echo $before_widget;

		if($warrior_latest_video_title)
			echo $before_title . $warrior_latest_video_title . $after_title;
?>
		<div id="video">
        	<?php if( !empty($warrior_latest_video_code) ) : ?>
            <div class="video-embed-code">
            	<?php echo $warrior_latest_video_code; ?>
            </div>
            <?php endif; ?>
            
            <?php if( !empty($warrior_latest_video_desc) ) : ?>
            	<div class="desc"><?php echo $warrior_latest_video_desc; ?></div>
            <?php endif; ?>
		</div>
<?php
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['warrior_latest_video_title']    = strip_tags( $new_instance['warrior_latest_video_title'] );
		$instance['warrior_latest_video_code']    = $new_instance['warrior_latest_video_code'];
		$instance['warrior_latest_video_desc'] = strip_tags( $new_instance['warrior_latest_video_desc'] );

		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array('warrior_latest_video_title' => __('Video', 'warrior'), 'warrior_latest_video_code' => '', 'warrior_latest_video_desc' => '') );
	?>
        <p>
            <label for="<?php echo $this->get_field_id( 'warrior_latest_video_title' ); ?>"><?php _e('Widget Title:', 'warrior'); ?></label>
            <input id="<?php echo $this->get_field_id( 'warrior_latest_video_title' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_latest_video_title' ); ?>" value="<?php echo $instance['warrior_latest_video_title']; ?>" />
        </p>
		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_latest_video_code' ); ?>"><?php _e('Video Embedded Codes:', 'warrior'); ?></label>
			<textarea id="<?php echo $this->get_field_id( 'warrior_latest_video_code' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_latest_video_code' ); ?>" rows="5"> <?php echo $instance['warrior_latest_video_code']; ?></textarea>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_latest_video_desc' ); ?>"><?php _e('Video Description:', 'warrior'); ?></label>
			<textarea id="<?php echo $this->get_field_id( 'warrior_latest_video_desc' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_latest_video_desc' ); ?>" rows="3"><?php echo $instance['warrior_latest_video_desc']; ?></textarea>
		</p>
	<?php
	}
}
?>