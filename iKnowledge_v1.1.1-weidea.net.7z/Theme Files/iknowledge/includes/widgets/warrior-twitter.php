<?php
/**
 * Warrior Twitter Widgets
 *
 * This file contains Twitter widget
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_twitter_widget' );

// Register our widget
function warrior_twitter_widget() {
	register_widget( 'Warrior_Twitter' );
}

// Warrior Twitter Widget
class Warrior_Twitter extends WP_Widget {


	//  Setting up the widget
	function Warrior_Twitter() {
		$widget_ops  = array( 'classname' => 'warrior_twitter', 'description' => __('Warrior Twitter Widget', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_twitter' );

		$this->WP_Widget( 'warrior_twitter', __('Warrior Twitter', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		global $shortname;

		extract( $args );

		$warrior_twitter_title        = apply_filters('widget_title', $instance['warrior_twitter_title']);
		$warrior_twitter_username     = $instance['warrior_twitter_username'];
		$warrior_twitter_tweets_count = !empty($instance['warrior_twitter_tweets_count']) ? $instance['warrior_twitter_tweets_count'] : 1;
		$warrior_twitter_button_text   = $instance['warrior_twitter_button_text'];

		echo $before_widget;
?>

		<?php echo $before_title . $warrior_twitter_title . $after_title; ?>

        <ul id="tweets">
            <li class="load"><?php _e('Loading...', 'warrior');?></li>
        </ul>

        <p class="follow">
            <a href="http://twitter.com/<?php echo $warrior_twitter_username;?>"><?php echo $warrior_twitter_button_text; ?></a>
        </p>

        <script type="text/javascript">
			//<![CDATA[
            jQuery(document).ready(function(){
				String.prototype.parseURL = function() {
					return this.replace(/[A-Za-z]+:\/\/[A-Za-z0-9-_]+\.[A-Za-z0-9-_:%&\?\/.=]+/g, function(url) {
						return url.link(url);
					});
				};
				String.prototype.parseUsername = function() {
					return this.replace(/[@]+[A-Za-z0-9-_]+/g, function(u) {
						var username = u.replace("@","")
						return u.link("http://twitter.com/"+username);
					});
				};
				String.prototype.parseHashtag = function() {
					return this.replace(/[#]+[A-Za-z0-9-_]+/g, function(t) {
						var tag = t.replace("#","%23")
						return t.link("http://search.twitter.com/search?q="+tag);
					});
				};

                jQuery.getJSON('https://api.twitter.com/1/statuses/user_timeline/<?php echo $warrior_twitter_username;?>.json?count=<?php echo $warrior_twitter_tweets_count;?>&include_rts=1&callback=?', function(data){
                    // Empty out the content
                    jQuery('#tweets').empty();

                    // Print out the tweets
                    jQuery.each(data, function(index, value){
                        // Format date
                        var d 		   = new Date(value.created_at);
                        var tweet_date = d.getDate();
                        var m_names    = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
                        var sup 	  = "";

                        if (tweet_date == 1 || tweet_date == 21 || tweet_date ==31){
                            sup = "st";
                        }else if (tweet_date == 2 || tweet_date == 22){
                            sup = "nd";
                        }else if (tweet_date == 3 || tweet_date == 23){
                            sup = "rd";
                        }else{
                            sup = "th";
                        }

                        var tweet_month = d.getMonth();
                        var tweet_year  = d.getFullYear();
                        var tweet_meta  = m_names[tweet_month] + " " + tweet_date + sup + ", " + tweet_year;
                        var tweet_text  = value.text;
                        var tweet = '<li class="tweet">' + tweet_text.parseURL().parseUsername().parseHashtag() + '<div class="meta">' + tweet_meta + '</div></li>';

                        jQuery('#tweets').append(tweet);
                    });
                });
            });
			//]]>
        </script>

<?php
	echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		global $shortname;

		$instance = $old_instance;

		$instance['warrior_twitter_title']        = strip_tags( $new_instance['warrior_twitter_title'] );
		$instance['warrior_twitter_username']     = strip_tags( $new_instance['warrior_twitter_username'] );
		$instance['warrior_twitter_tweets_count'] = strip_tags( $new_instance['warrior_twitter_tweets_count'] );
		$instance['warrior_twitter_button_text']  = strip_tags( $new_instance['warrior_twitter_button_text'] );

		return $instance;
	}

	function form( $instance ) {
		global $shortname;

		$instance = wp_parse_args( (array) $instance, array('warrior_twitter_title' => __('Latest Tweets', 'warrior'), 'warrior_twitter_username' => 'themewarrior', 'warrior_twitter_tweets_count' => '1', 'warrior_twitter_button_text' => __('Follow me on Twitter', 'warrior') ) );
	?>
        <p>
            <label for="<?php echo $this->get_field_id( 'warrior_twitter_title' ); ?>"><?php _e('Widget Title:', 'warrior'); ?></label>
            <input id="<?php echo $this->get_field_id( 'warrior_twitter_title' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_twitter_title' ); ?>" value="<?php echo $instance['warrior_twitter_title']; ?>" />
        </p>
		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_twitter_username' ); ?>"><?php _e('Twitter Username (this will also change the username in the WarriorPanel):', 'warrior'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'warrior_twitter_username' ); ?>" name="<?php echo $this->get_field_name( 'warrior_twitter_username' ); ?>" value="<?php echo $instance['warrior_twitter_username']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_twitter_tweets_count' ); ?>"><?php _e('Tweets Count:', 'warrior'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'warrior_twitter_tweets_count' ); ?>" name="<?php echo $this->get_field_name( 'warrior_twitter_tweets_count' ); ?>" value="<?php echo $instance['warrior_twitter_tweets_count']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_twitter_button_text' ); ?>"><?php _e('Button Text:', 'warrior'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'warrior_twitter_button_text' ); ?>" name="<?php echo $this->get_field_name( 'warrior_twitter_button_text' ); ?>" value="<?php echo $instance['warrior_twitter_button_text']; ?>" />
	<?php
	}
}
?>