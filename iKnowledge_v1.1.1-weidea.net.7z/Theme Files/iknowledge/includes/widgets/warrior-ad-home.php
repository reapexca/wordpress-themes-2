<?php
/**
 * Warrior Sidebar 290x290 Ad Widget
 *
 * This file contains Sidebar 290x290 Ad widget
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_ad_home_widget' );

// Register our widget
function warrior_ad_home_widget() {
	register_widget( 'Warrior_Ad_Home_Widget' );
}

// Warrior Ad Home Widget
class Warrior_Ad_Home_Widget extends WP_Widget {

	//  Setting up the widget
	function Warrior_Ad_Home_Widget() {
		$widget_ops  = array( 'classname' => 'warrior_ad_home', 'description' => __('Warrior Ad on Homepage', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_ad_home' );

		$this->WP_Widget( 'warrior_ad_home', __('Home: Warrior Ad Home', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		global $shortname;
		
		extract( $args );
		if ( is_home() ) {
			echo $before_widget;
			
			if ( get_option($shortname.'_ad_home') != "" ) {
				echo '<a href="'. stripslashes(get_option($shortname.'_ad_home_url')) .'"><img src="'. stripslashes(get_option($shortname.'_ad_home')) .'" alt="" /></a>';
			}
			
		echo $after_widget;
		}
	}

	function update( $new_instance, $old_instance ) {
	}

	function form( $instance ) {
		global $shortname;
		
		echo _e('This widget doesn\'t have any option available.', 'warrior');
	}
}
?>