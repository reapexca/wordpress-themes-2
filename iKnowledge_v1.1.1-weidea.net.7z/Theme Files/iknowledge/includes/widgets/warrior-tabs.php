<?php
/**
 * Warrior Tabs Widgets
 *
 * This file contains Latest Posts widget
 * @copyright Copyright (c) 2010, Warrior
 */
// Widgets
add_action( 'widgets_init', 'warrior_tabs_widget' );

// Register our widget
function warrior_tabs_widget() {
	register_widget( 'Warrior_Tabs' );
}

// Testimonial Warrior Widget
class Warrior_Tabs extends WP_Widget {

	//  Setting up the widget
	function Warrior_Tabs() {
		$widget_ops  = array( 'classname' => 'warrior_tabs', 'description' => __('Warrior Tabs Widget', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_tabs' );

		$this->WP_Widget( 'warrior_tabs', __('Warrior Tabs', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		global $shortname;

		extract( $args );

		$warrior_tabs_latest_posts_total   = $instance['warrior_tabs_latest_posts_total'];
		$warrior_tabs_most_commented_total = $instance['warrior_tabs_most_commented_total'];
		
		echo $before_widget;
?>
        <div id="tabs">
            <ul class="tab-items">
                <li><a class="tab1" href="#tab1"><?php _e('Recent', 'warrior'); ?></a></li>
                <li><a class="tab2" href="#tab2"><?php _e('Popular', 'warrior'); ?></a></li>
                <li class="last"><a class="tab3" href="#tab3"><?php _e('Tags', 'warrior'); ?></a></li>
            </ul>
           <div class="idas clearfix">
            <div id="tab1" class="tab">
                <?php global $post; ?>
                <ul class="list">
                    <?php
                        // Start fetching the post from database
                        $warrior_tabs_latest_posts = new WP_Query("showposts=$warrior_tabs_latest_posts_total&ignore_sticky_posts=1");
                        while($warrior_tabs_latest_posts->have_posts()) : $warrior_tabs_latest_posts->the_post();
                    ?>
                    <li id="post-<?php the_ID(); ?>">
                        <h4 class="title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>
                        <div class="meta"><?php echo get_the_date( get_option($shortname.'_date_format') ); ?></div>
                    </li>
                    <?php endwhile; ?>
                </ul>
                <?php wp_reset_query(); ?>
            </div>
            <div id="tab2" class="tab">
                <?php global $wpdb; ?>
                <ul class="list">
                    <?php
                        $warrior_tabs_most_commented = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}posts WHERE post_type='post' AND post_status='publish' ORDER BY comment_count DESC LIMIT 0,".$warrior_tabs_most_commented_total);
                        foreach($warrior_tabs_most_commented as $post):
                            setup_postdata($post);
                    ?>
                    <li id="post-popular-<?php the_ID(); ?>">
                        <h4 class="title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>
                        <div class="meta"><?php echo get_the_date( get_option($shortname.'_date_format') ); ?></div>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php wp_reset_query(); ?>
            </div>
            <div id="tab3" class="tab">
				<div class="tagcloud">
					<?php wp_tag_cloud(); ?>
				</div>
            </div>
            </div>
        </div>

        <script type="text/javascript">
            //<![CDATA[
            jQuery(document).ready(function($) {
                "use strict";
                $("#tabs").tabs();
            });
            //]]>
        </script>
<?php
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['warrior_tabs_latest_posts_total'] = strip_tags( $new_instance['warrior_tabs_latest_posts_total'] );
		$instance['warrior_tabs_most_commented_total'] = strip_tags( $new_instance['warrior_tabs_most_commented_total'] );

		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array('warrior_tabs_latest_posts_total'=>'5', 'warrior_tabs_most_commented_total'=>'5') );
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_tabs_latest_posts_total' ); ?>"><?php _e('Number of Latest Posts to be Displayed:', 'warrior'); ?></label>
			<input id="<?php echo $this->get_field_id( 'warrior_tabs_latest_posts_total' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_tabs_latest_posts_total' ); ?>" value="<?php echo $instance['warrior_tabs_latest_posts_total']; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'warrior_tabs_most_commented_total' ); ?>"><?php _e('Number of Most Commented Posts to be Displayed:', 'warrior'); ?></label>
			<input id="<?php echo $this->get_field_id( 'warrior_tabs_most_commented_total' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_tabs_most_commented_total' ); ?>" value="<?php echo $instance['warrior_tabs_most_commented_total']; ?>" />
		</p>
	<?php
	}
}
?>