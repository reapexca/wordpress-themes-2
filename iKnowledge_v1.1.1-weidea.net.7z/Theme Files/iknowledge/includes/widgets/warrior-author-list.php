<?php
/**
 * Warrior Author List
 * This file contains author list
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_author_list_widget' );

// Register our widget
function warrior_author_list_widget() {
	register_widget( 'Warrior_Author_List' );
}

// Warrior Author List Widget
class Warrior_Author_List extends WP_Widget {

	//  Setting up the widget
	function Warrior_Author_List() {
		$widget_ops  = array( 'classname' => 'warrior_author_list', 'description' => __('Warrior Author List Widget', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior_author_list', 'width' => '300' );

		$this->WP_Widget( 'warrior_author_list', __('Warrior Author List', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		global $shortname;
		
		extract( $args );

		$warrior_author_list_title	= apply_filters('widget_title', $instance['warrior_author_list_title'] );

		echo $before_widget;
		
		echo $before_title . $warrior_author_list_title . $after_title;
		
		// Let's query the authors from database
		global $wpdb;
		$warrior_get_authors = $wpdb->get_results("SELECT u.ID from $wpdb->users u, $wpdb->usermeta um WHERE u.ID = um.user_id AND meta_key = 'description' ORDER BY u.display_name");
		
		$authors = array();
	
		foreach($warrior_get_authors as $warrior_author) {
			$user_info  = get_userdata($warrior_author->ID);
			$user_post  = $wpdb->get_results(" SELECT * from $wpdb->posts WHERE post_author = '$warrior_author->ID' AND post_type = 'post' AND post_status = 'publish' ");		
			$role  = !empty( $instance['warrior_author_hide_admin'] ) ? '10' : '0';
			$count = !empty( $instance['warrior_author_hide_nopost'] ) ? '0' : '-1';
			
			if ( $user_info->user_level != $role && $user_info->user_level != '' && $user_info->user_level != '0' && count($user_post) > $count ) {
				$authors[] = array( 'id' => $warrior_author->ID, 'count' => count($user_post) );
			}
		}
		
		$content = '';
		if ( $authors ) {	
		$content .= "<ul class='contributors'>";
			foreach($authors as $author) {
				$content .= '<li>';
				$content .= '<span class="bg"><a href='. get_author_posts_url($author['id']) .' title='. get_the_author_meta('display_name', $author['id']) .'>'. get_avatar(get_the_author_meta('user_email', $author['id']), 50) .'</a></span>';
				$content .= '</li>';				
			}
		$content .= "</ul>";
		}

	echo $content;
?>
		
<?php
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['warrior_author_list_title']	= strip_tags( $new_instance['warrior_author_list_title'] );
		$instance['warrior_author_hide_admin'] 	= isset($new_instance['warrior_author_hide_admin']);
		$instance['warrior_author_hide_nopost'] = isset($new_instance['warrior_author_hide_nopost']);
		
		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array('warrior_author_list_title' => __('Author List', 'warrior') ) );
	?>
        <p>
            <label for="<?php echo $this->get_field_id( 'warrior_author_list_title' ); ?>"><?php _e('Widget Title:', 'warrior'); ?></label>
            <input id="<?php echo $this->get_field_id( 'warrior_author_list_title' ); ?>" class="widefat" name="<?php echo $this->get_field_name( 'warrior_author_list_title' ); ?>" value="<?php echo $instance['warrior_author_list_title']; ?>" />
        </p>
		<p>
			<input id="<?php echo $this->get_field_id('warrior_author_hide_admin'); ?>" name="<?php echo $this->get_field_name('warrior_author_hide_admin'); ?>" type="checkbox" <?php checked(isset($instance['warrior_author_hide_admin']) ? $instance['warrior_author_hide_admin'] : 0); ?> />
			<label for="<?php echo $this->get_field_id('warrior_author_hide_admin'); ?>"><?php _e('Hide Administrator(s)', 'warrior'); ?></label>
		</p>
		<p>
			<input id="<?php echo $this->get_field_id('warrior_author_hide_nopost'); ?>" name="<?php echo $this->get_field_name('warrior_author_hide_nopost'); ?>" type="checkbox" <?php checked(isset($instance['warrior_author_hide_nopost']) ? $instance['warrior_author_hide_nopost'] : 0); ?> />
			<label for="<?php echo $this->get_field_id('warrior_author_hide_nopost'); ?>"><?php _e('Hide author(s) that have no post', 'warrior'); ?></label>
		</p>
	<?php
	}
}
?>