<?php
/**
 * Warrior Advanced Search
 *
 * This file contains Advanced Search widget
 */
 
// Widgets
add_action( 'widgets_init', 'warrior_advanced_search' );

// Register our widget
function warrior_advanced_search() {
	register_widget( 'Warrior_Advanced_Search' );
}

// Warrior Latest Posts Widget
class Warrior_Advanced_Search extends WP_Widget {

	//  Setting up the widget
	function Warrior_Advanced_Search() {
		$widget_ops  = array( 'classname' => 'warrior-advanced-search', 'description' => __('Warrior Advanced Search', 'warrior') );
		$control_ops = array( 'id_base' => 'warrior-advanced-search' );

		$this->WP_Widget( 'warrior-advanced-search', __('Home: Warrior Advanced Search', 'warrior'), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		
		if ( ( empty( $instance['warrior_display_all_pages'] ) && is_home() ) || ( !empty( $instance['warrior_display_all_pages'] ) ) ) {
			echo $before_widget;
?>
		<form method="get" id="warrior-advanced-search" action="<?php echo home_url( '/' ); ?>" >
            <div class="form-item">
                <input value="<?php the_search_query(); ?>" name="s" id="s" type="text" />
                <button id="searchsubmit" type="submit"><span class="icon-search"></span> <em><?php _e('Search', 'warrior'); ?></em></button>
            </div>
        
			<div id="advanced-search" class="clearfix" style="display: none;">
				<div class="category">
					<label><?php _e('Category:', 'warrior' ); ?></label>
					<?php wp_dropdown_categories('show_count=0&hierarchical=1&show_option_all=All Categories'); ?>
				</div>
				<div class="date">
					<label><?php _e('Date:', 'warrior' ); ?></label>
					<div class="date-inputs clearfix">
						<input name="fromdate" id="fromdate" class="datepicker" value="<?php echo isset($_GET['fromdate'])? $_GET['fromdate'] : 'From'; ?>" type="text" />
						<input name="todate" id="todate" class="datepicker" value="<?php echo isset($_GET['todate'])? $_GET['todate'] : 'Until'; ?>" type="text" />
					</div>
				</div>
			</div>

            <div class="advanced-search">
				<a style="cursor:pointer;" id="click-advanced-search"><?php _e('Advanced Search', 'warrior'); ?></a>
				<span class="before"></span>
				<span class="after"></span>
			</div>
		</form>
        
        <script type="text/javascript">
			//<![CDATA[
			jQuery(document).ready(function($) {
				"use strict";

				// Set search box value
				$('#warrior-advanced-search input#s').val('Type in your keyword ...');
				$('#warrior-advanced-search #s').blur(function(){
					if ($('#warrior-advanced-search #s').val() === ''){
						$('#warrior-advanced-search #s').val('Type in your keyword ...');
					}
				});
				$('#warrior-advanced-search #s').focus(function(){
					if ($('#warrior-advanced-search #s').val() === 'Type in your keyword ...'){
						$('#warrior-advanced-search #s').val('');
					}
				});

				$('#advanced-search').hide();
				var advancedSearchClose = true;
				$('#click-advanced-search').click(function() {
					$('#advanced-search').slideToggle(300, function() {
						if ( advancedSearchClose ){
							$('#click-advanced-search').html('<?php _e('Close [x]', 'warrior'); ?>');
							advancedSearchClose = false;
							$('.warrior-advanced-search').addClass('warrior-advanced-search-toogle');
						} else {
							$('#click-advanced-search').html('<?php _e('Advanced Search', 'warrior'); ?>');
							advancedSearchClose = true;
							$('.warrior-advanced-search').removeClass('warrior-advanced-search-toogle');
						}
					});
				
				});
				
				$('.input#s').keypress(function(e){
					if(e.which === 13){
						jQuery('#warrior-advanced-search').submit();
					}
				});

				$(function() {
					$( ".datepicker" ).datepicker({
						changeMonth: true,
						changeYear: true,
						dateFormat: 'yy-mm-dd'
					});
				});
			});
			//]]>
		</script>
        
<?php
			echo $after_widget;
		}
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['warrior_display_all_pages'] = isset($new_instance['warrior_display_all_pages']);

		return $instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array('warrior_display_all_pages' => '1') );
?>
		<p>
			<input id="<?php echo $this->get_field_id('warrior_display_all_pages'); ?>" name="<?php echo $this->get_field_name('warrior_display_all_pages'); ?>" type="checkbox" <?php checked(isset($instance['warrior_display_all_pages']) ? $instance['warrior_display_all_pages'] : 0); ?> />
			<label for="<?php echo $this->get_field_id('warrior_display_all_pages'); ?>"><?php _e('Display this widget on all pages', 'warrior'); ?></label>
		</p>
<?php
	}
}
?>