<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

	<div id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?>>
				
		<h2 class="title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a><span></span></h2>
				
		<?php warrior_box_info(); ?>
					
	</div>
			
<?php endwhile; ?>

		<?php global $wp_query; if($wp_query->max_num_pages > 1) : ?>
		<div class="navigation clearfix">
			<?php
			if(function_exists('wp_pagenavi')):
				wp_pagenavi();
			else:
			?>
			<div class="prev"><?php previous_posts_link(__('&laquo; Previous', 'warrior')); ?></div>
			<div class="next"><?php next_posts_link(__('Next &raquo;', 'warrior')); ?></div>
			<?php endif; ?>
		</div>
		<?php endif; ?>
	
<?php else: ?>

	<div id="post-0" class="post error404 not-found hentry clearfix">
		<div class="entry">
				<p><?php _e('The page you\'re looking for is not available. The page may have been deleted or unpublished.', 'warrior');?></p>
		</div>

	</div>
	
<?php endif; ?>

<?php wp_reset_query(); ?>