//<![CDATA[
jQuery(document).ready(function($) {
	"use strict";
	
	// Dropdown Menu
	$('#access ul.top-menu').superfish({ 
        delay:       300,
        animation:   {opacity:'show',height:'show'},
        speed:       'fast',
        dropShadows: false
	});
	
	// Post Rating
	$('.post-rating label').each(function () {
		$(this).html($(this).html().replace($(this).html(),'Rate this post :'));
	});
	
	// Add Element
	$('#access ul.top-menu ul').append('<span class="arrow" />'); 
	$('.articles .hentry:nth-child(3n)').addClass('third');
	$('.articles .hentry:nth-child(2n)').addClass('half');
	$('#respond h3').addClass('title');
	$('#leftcol, .bg-area .bg-left').prepend('<div class="before" />').append('<div class="after" />');

	// home widget title
	$('#rightcol .widget .title').each(function(){
		$('span',this).width( $('label',this).width() + 20 );
	});

	// Responsive Menu
	$('#main-menu').mobileMenu({
		defaultText: 'Select Menu',
		className: 'main-menu',
		subMenuDash: '&ndash;'
	});
	$('#top select, #access select').each(function(){
		$(this).css('opacity',0).wrap('<div id="select-'+$(this).attr('class')+'" class="menu-select" />');
		$(this).parent().prepend('<span>'+$(this).find('option:first-child').text()+' <em class="icon-chevron-down"></em></span>');
	});


	
	// #rightcol width to 100%
	$('#rightcol').css('width',$('#footer .footer-area').width());
	$(window).bind('resize', function(){
		$('#rightcol').css('width',$('#footer .footer-area').width());
	});

});
//]]>