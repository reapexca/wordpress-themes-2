	</div>

	<!-- START: FOOTER -->
	<div id="footer" class="clearfix">
		<div class="container">
			<div class="footer-area">
				<div class="copyright">
					<?php printf( __( '%1$s. Copyright %2$s. All rights reserved.', 'warrior' ), get_bloginfo('name'), date('Y') ); ?>
				</div>
				<div class="generator">
					<?php _e('Powered by', 'warrior'); ?> <a href="http://wordpress.org"><?php _e('WordPress', 'warrior'); ?></a>. <?php _e('Designed by' ,'warrior'); ?> <a href="http://www.themewarrior.com"><img src="<?php bloginfo('template_url') ?>/images/logo-themewarrior.png" alt="<?php _e('Premium WordPress Themes', 'warrior'); ?>" title="<?php _e('Premium WordPress Themes', 'warrior'); ?>" /></a>
				</div>
			</div>
		</div>
	</div>
	<!-- END: FOOTER -->
	
	<div class="bg-area clearfix">
		<div class="container">
			<div class="bg-left">
			</div>
		</div>
	</div>
			
<?php wp_footer(); ?>
</body>
</html>