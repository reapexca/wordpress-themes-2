<?php
/**
 * Warrior Widgets
 * Register sidebar & load widget files
*/

function warrior_register_sidebars(){
	// Sidebar Widget
	if ( function_exists('register_sidebar') ) {
		register_sidebar(array(
			'name' => __('Sidebar', 'warrior'),
			'before_widget' => '<div id="widget-%1$s" class="widget %2$s">'."\n",
			'after_widget' => '</div>'."\n",
			'before_title' => '<h3 class="title"><span class="icon-th-large"></span>',
			'after_title' => '</h3>',
		));
	}	

	// Homepage Widget
	if ( function_exists('register_sidebar') ) {
		register_sidebar(array(
			'name' => __('Homepage', 'warrior'),
			'before_widget' => '<div id="widget-%1$s" class="widget %2$s clearfix">'."\n",
			'after_widget' => '</div>'."\n",
			'before_title' => '<h3 class="title"><label>',
			'after_title' => '</label><span></span></h3>',
		));
	}
}

// Load Custom Widgets
include(TEMPLATEPATH . '/includes/widgets/warrior-tabs.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-author-list.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-advanced-search.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-twitter.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-video.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-latest-posts.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-sticky-posts.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-ad-home.php');
include(TEMPLATEPATH . '/includes/widgets/warrior-categories.php');
?>