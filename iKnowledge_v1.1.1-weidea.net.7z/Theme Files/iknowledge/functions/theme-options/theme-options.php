<?php
/* All Theme Options
   the $theme_options is a global variable to define specific theme's theme options
   when $theme_options set it will automaticly insert a new menu called 'Theme Options'
*/

//Access the WordPress Categories via an Array
$categories_array = array();  
$categories_name_array = array();  
$categories_obj = get_categories('hierarchical=true&orderby=name');

$categories_name_array = array_cat_list_name(0, $categories_obj, $categories_array, 0);
$categories_array = array_cat_list_id(0, $categories_obj, $categories_array, 0);

$theme_options = array();


// Create General Tab
$theme_options[] = array( "name" => "General",
					"class" => "general",
					"id" => "menu-general",
                    "type" => "open-tab");
					
$theme_options[] = array( "name" => "Post Options",
                    "type" => "heading");

$theme_options[] = array( "name" => "Display Update Post Link",
					"id" => $shortname . "_update_link",
					"std" => "Yes",
                    "type" => "switch",
					"desc" => "If set to ON, the update post link will be displayed to logged in administrator and users with editing rights.");

$theme_options[] = array( "name" => "Rating Options",
                    "type" => "heading");

$theme_options[] = array( "name" => "Anonymous Rating",
					"id" => $shortname . "_anonymous_rating",
					"std" => "Yes",
                    "type" => "switch",
					"desc" => "When it's turned ON, everyone can rate posts. If set to OFF only registered user can rate the posts.");

$theme_options[] = array( "name" => "Replace Rating",
					"id" => $shortname . "_replace_rating",
					"std" => "No",
                    "type" => "switch",
					"desc" => "When it's turned ON, user can overwrite their previous rating.");

$theme_options[] = array( "name" => "Anonymous User Expire",
					"id" => $shortname . "_rating_anonymous_expire",
					"std" => "1 day",
                    "type" => "select2",
					"options" => array('30 minutes','1 hour', '3 hours', '6 hours', '12 hours', '1 day' , '2 days', '4 days', '1 week', 'never'),
					"desc" => "Time delay for anonymous user able to rate again.");

$theme_options[] = array( "name" => "Menu Setting",
                    "type" => "heading");

$theme_options[] = array( "name" => "Display Home Menu",
					"id" => $shortname . "_home_link",
					"std" => "Yes",
                    "type" => "switch",
					"desc" => "If set to ON, it will displays the 'Home' link.<br/>Don't must to adding the 'Home' when you create <a href='nav-menus.php' target='_blank'>the menu</a>.");

// Close General Tab
$theme_options[] = array( "type" => "close-tab");					

// Create New Appereance Tab
$theme_options[] = array( "name" => "Appearance",
					"class" => "appearance",
					"id" => "menu-appear",
                    "type" => "open-tab");
					
$theme_options[] = array( "name" => "Styles",
                    "type" => "heading");

$theme_options[] = array( "name" => "Theme Style",
					"id" => $shortname . "_style",
					"std" => "default",
					"options" => array('default','blue','brown','light-gray'),
					"type" => "select2",
					"desc" => "Which style should be use for the theme.");

$theme_options[] = array( "name" => "Favicon",
					"id" => $shortname . "_favicon",
					"std" => "",
                    "type" => "file",
					"desc" => "Upload your favicon. Only JPG, GIF and PNG image allowed. Suggested image dimension 32x32 pixels.");

$theme_options[] = array( "name" => "Logo",
					"id" => $shortname . "_logo",
					"std" => "",
                    "type" => "file",
					"desc" => "Upload your logo or type the URL on the text box. Only JPG, GIF and PNG image allowed.");

$theme_options[] = array( "name" => "Font &amp; Color Settings",
                    "type" => "heading");

$theme_options[] = array( "name" => "Font Family",
					"id" => $shortname . "_font",
					"std" => "Helvetica",
                    "type" => "select2",
					"options" => array('Helvetica', 'Arial', 'Verdana', 'Tahoma', 'Georgia', 'Lucida Sans'),
					"desc" => "Choose font family.");

$theme_options[] = array( "name" => "Main Text Color",
					"id" => $shortname . "_color_text",
					"std" => "",
                    "type" => "color",
					"desc" => "Enter color code. Example: #333333.");

$theme_options[] = array( "name" => "Main Link Color",
					"id" => $shortname . "_color_link",
					"std" => "",
                    "type" => "color",
					"desc" => "Enter color code. Example: #dedede.");

$theme_options[] = array( "name" => "Main Link Hover Color",
					"id" => $shortname . "_color_hover",
					"std" => "",
                    "type" => "color",
					"desc" => "Enter color code. Example: #ff0000.");

$theme_options[] = array( "name" => "Main Link Visited Color",
					"id" => $shortname . "_color_visited",
					"std" => "",
                    "type" => "color",
					"desc" => "Enter color code. Example: #ff0000.");

$theme_options[] = array( "name" => "Custom CSS Codes",
                    "type" => "heading");

$theme_options[] = array( "name" => "Custom CSS Codes",
					"id" => $shortname . "_custom_css",
					"std" => "",
                    "type" => "textarea",
					"desc" => "Type your custom CSS codes here, alternatively you can also write down you custom CSS styles on the custom.css file located on the theme root directory.");

// Close Appearance Tab
$theme_options[] = array( "type" => "close-tab");

// Create New Advertisment Tab
$theme_options[] = array( "name" => "Advertisement",
					"class" => "advertisement",
					"id" => "menu-advertisement",
                    "type" => "open-tab");

$theme_options[] = array( "name" => "Homepage Advertisement Banner",
                    "type" => "heading");
					
$theme_options[] = array( "name" => "<h3>Information</h3>Recommended width of this ad is 700 pixel. To display these banner images, you need to add Warrior Ad Home Widget from the <a href='widgets.php'>widgets setting</a> page",
                    "type" => "info");

$theme_options[] = array( "name" => "Banner Location",
					"id" => $shortname . "_ad_home",
					"std" => "",
                    "type" => "file",
					"desc" => "Enter the location of the banner image or upload your own banner image.");

$theme_options[] = array( "name" => "Banner URL",
					"id" => $shortname . "_ad_home_url",
					"std" => "",
                    "type" => "text",
					"desc" => "Where should this banner linked to?");
				
// Close Advertisment Tab
$theme_options[] = array( "type" => "close-tab");

// Create New Social Networks Tab
$theme_options[] = array( "name" => "Social Network",
 					"class" => "socnet",
					"id" => "menu-socnet",
                   "type" => "open-tab");

$theme_options[] = array( "name" => "Social Network Profiles",
                    "type" => "heading");

$theme_options[] = array( "name" => "Feed URL",
					"id" => $shortname . "_feed",
					"std" => "",
                    "type" => "text",
					"desc" => "Your site's feed url. Example: http://www.themewarrior.com/feed");

$theme_options[] = array( "name" => "Twitter Profile",
					"id" => $shortname . "_twitter",
					"std" => "http://twitter.com/themewarrior",
                    "type" => "text",
					"desc" => "Your Twitter profile page. Example: http://twitter.com/themewarrior");

$theme_options[] = array( "name" => "Facebook Profile/Page",
					"id" => $shortname . "_facebook",
					"std" => "",
                    "type" => "text",
					"desc" => "Your Facebook profile page. Example: http://www.facebook.com/themewarrior");

$theme_options[] = array( "name" => "Myspace Page",
					"id" => $shortname . "_myspace",
					"std" => "http://www.myspace.com/themewarrior",
                    "type" => "text",
					"desc" => "Your MySpace profile page. Example: http://www.myspace.com/themewarrior");

$theme_options[] = array( "name" => "Linkedin Profile",
					"id" => $shortname . "_linkedin",
					"std" => "",
                    "type" => "text",
					"desc" => "Your LinkedIn profile page. Example: http://www.linkedin.com/in/andrayogi");

$theme_options[] = array( "name" => "Flickr Photos",
					"id" => $shortname . "_flickr",
					"std" => "",
                    "type" => "text",
					"desc" => "Your Flickr Photos page. Example: http://www.flickr.com/photos/themewarrior");

$theme_options[] = array( "name" => "Youtube Videos",
					"id" => $shortname . "_youtube",
					"std" => "",
                    "type" => "text",
					"desc" => "Your YouTube video page. Example: http://www.youtube.com/user/andrastudio");

$theme_options[] = array( "name" => "Vimeo Videos",
					"id" => $shortname . "_vimeo",
					"std" => "http://www.vimeo.com/themewarrior",
                    "type" => "text",
					"desc" => "Your Vimeo video page. Example: http://www.vimeo.com/themewarrior");
					
// Close Social Networks Tab
$theme_options[] = array( "type" => "close-tab");

// Create New Miscellaneous Tab
$theme_options[] = array( "name" => "Miscellaneous",
					"class" => "miscellaneous",
					"id" => "menu-miscellaneous",
                    "type" => "open-tab");

$theme_options[] = array( "name" => "Header &amp; Footer Codes",
                    "type" => "heading");

$theme_options[] = array( "name" => "Header Codes",
					"id" => $shortname . "_header_codes",
					"std" => "",
                    "type" => "textarea",
					"desc" => "Paste any Javascript or CSS codes you want to load in &lt;head&gt;.");

$theme_options[] = array( "name" => "Footer Codes",
					"id" => $shortname . "_footer_codes",
					"std" => "",
                    "type" => "textarea",
					"desc" => "Paste your Google Analytics code or any other codes to be placed on footer.");

$theme_options[] = array( "type" => "close-tab");


// Create ThemeForest Tab
$theme_options[] = array( "name" => "Auto Update",
					"class" => "general",
					"id" => "menu-tf",
                    "type" => "open-tab");
					
$theme_options[] = array( "name" => "Auto Update Settings",
                    "type" => "heading");
					
$theme_options[] = array( "name" => "<h3>Information</h3>Auto updater relies on Envato WordPress Toolkit plugin. You need to download and install it first to use the auto updater function. <a href='https://github.com/envato/envato-wordpress-toolkit' target='_blank'>Download</a> now!",
                    "type" => "info");

$theme_options[] = array( "name" => "ThemeForest Username",
					"id" => $shortname . "_tf_username",
					"std" => "",
                    "type" => "text",
					"desc" => "Your ThemeForest username (the one you used to buy this theme.");

$theme_options[] = array( "name" => "ThemeForest API Key",
					"id" => $shortname . "_tf_api_key",
					"std" => "",
                    "type" => "text",
					"desc" => "ThemeForest API Key. Don't have one? <a href='http://themeforest.net/user/ThemeWarriors/api_keys/edit' target='_blank'>Create one</a> now!");

// Close General Tab
$theme_options[] = array( "type" => "close-tab");
?>