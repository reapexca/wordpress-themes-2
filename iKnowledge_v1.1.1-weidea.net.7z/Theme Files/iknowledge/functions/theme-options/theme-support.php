<?php
/**
* List of theme support functions
*/


// Check if the function exist
if ( function_exists( 'add_theme_support' ) ){
	global $wp_version;

	// Add post thumbnail feature
	add_theme_support( 'post-thumbnails' );
	add_image_size('small-thumb', 50, 50, true); // Widget image
	add_image_size('thumb', 80, 80, true); // Post featured image
	
	// Add WordPress navigation menus
	function warrior_nav_menu(){
		add_theme_support('nav-menus');
		register_nav_menus( array(
			'top-menu' => __( 'Top Menu', 'warrior' ),
		) );
	}
	
	// Add custom background feature 
	add_theme_support( 'custom-background' );
	
	// Add default posts and comments RSS feed links to head
	add_theme_support( 'automatic-feed-links' );
}

// Theme Localization
load_theme_textdomain('warrior', get_template_directory().'/lang');

// Set maximum image width displayed in a single post or page
if ( ! isset( $content_width ) ) {
	$content_width = 700;
}
?>