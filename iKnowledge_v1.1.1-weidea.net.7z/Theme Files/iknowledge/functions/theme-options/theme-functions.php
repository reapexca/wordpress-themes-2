<?php
/**
 * Theme Custom Functions
 *
 * Functions used in the theme
 */
 

/**
 * Warrior Menu
 *
 * Adding Home to Nav Menu
 */
add_filter('wp_nav_menu_items','add_home_link',10,2);
function add_home_link($items, $args) {
  global $shortname;

  if ( is_front_page() || is_home() ) :  $class = 'menu-item page-item-0 current-menu-item page_item current_page_item menu-item-0'; else: $class = 'menu-item page-item-0 page_item menu-item-0'; endif;
  
  if ( get_option($shortname.'_home_link') == "Yes" ) { 
  $homeMenuItem = '<li class="'.$class.'">'.$args->before.'<a href="'.home_url('/').'" title="Home">'.$args->link_before.'Home'.$args->link_after.'</a>'.$args->after.'</li>'."\n";
  } else {
  $homeMenuItem = '';
  }
  
  $items = $homeMenuItem . $items;
return $items;
}


/**
 * Warrior Post Info
 */
function warrior_post_info(){
?>
	<div class="meta clearfix">
		<span class="date"><?php the_time( get_option('date_format') .', '. get_option('time_format') ); ?></span>
		<span class="author"><?php _e('Posted by ', 'warrior'); the_author_posts_link(); ?></span>
		<span class="comment-count"><?php comments_popup_link( __( '0 Comment', 'warrior' ), __( '1 Comment', 'warrior' ), __( '% Comments', 'warrior' ), '', __( 'Comments are off', 'warrior' ) ); ?></span>
	</div>
<?php
}


/**
 * Warrior Comments
 *
 * Function to load comment list
 */
function warrior_comment_list($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case '' :
?>
			<li id="comment-<?php comment_ID() ?>" <?php comment_class(); ?>>
				<div class="comment-box clearfix">
					<div class="author">
						<?php comment_author_link(); ?>
						<?php echo get_avatar( $comment, 70 ); ?>
					</div>
					<div class="comment-body">
						<?php if ($comment->comment_approved == '0') : ?>
							<p class="moderate"><?php _e('Your comment is now awaiting moderation before it will appear on this post.', 'warrior');?></p>
						<?php endif; ?>
						<?php comment_text(); ?>
					</div>
					<div class="meta">
						<?php comment_date(); echo ' - '; comment_time(); ?>
						<?php echo comment_reply_link(array('before' => ' &ndash; ', 'after' => '', 'reply_text' => __('Reply', 'warrior'), 'depth' => $depth, 'max_depth' => $args['max_depth'] ));  ?>
						<?php edit_comment_link(__('Edit Comment', 'warrior'), ' &ndash; [', ']'); ?> 
					</div>
					<hr class="comment-line"/>
				</div>
<?php
		break;
		case 'pingback'  :
		case 'trackback' :
?>
			<li id="comment-<?php comment_ID() ?>" <?php comment_class(); ?>>
				<div class="comment-box clearfix">
					<div class="author">
						<a href="<?php comment_author_url()?>"><?php _e('Pingback', 'warrior'); ?></a>
					</div>
					<div class="comment-body">
						<?php comment_author(); ?>
					</div>
					<div class="meta">
						<?php comment_date(); echo ' - '; comment_time(); ?>
						<?php edit_comment_link(__('Edit Comment', 'warrior'), ' &ndash; [', ']'); ?> 
					</div>
					<hr class="comment-line"/>
				</div>
<?php
		break;
	endswitch;
}


/**
 * Warrior Box Info
 *
 * Function to display post info
 */
function warrior_box_info() { 
	global $post;
?>
	<div class="meta-box clearfix">
		<div class="publised">
			<p><?php printf( __( 'Published on %1$s by %2$s', 'warrior' ), get_the_time( get_option('date_format') ), get_the_author_link() ); ?></p>
			<?php if ( !is_page() ) { ?><p><?php _e( 'Filed under', 'warrior' ); ?> <?php the_category(', '); ?></p><?php } ?>
			<?php if ( the_modified_date('', '', '', false) ) { 
				echo '<p>' . sprintf( __( 'Last modified %s', 'warrior' ), the_modified_date( get_option('date_format'), '', '', false ) ) . '</p>';
			} ?>
            <?php if( is_single() || is_page() ) : ?>
            	<span class="print"><?php warrior_print_link(); ?></span>
            <?php endif; ?>
		</div>
		<div class="shared">
			<div class="post-rating"><?php warrior_post_rating($post->ID); ?></div>
			<p><?php printf( __( 'This article have been viewed %s times', 'warrior' ), warrior_page_view($post->ID) ); ?></p>
			<?php warrior_social_buttons(); ?>
		</div>
		<?php echo get_avatar($post->post_author, '70'); ?>
	</div>
<?php
}

/**
 * Warrior Social Buttons
 *
 * Function to shared post or page
 */
function warrior_social_buttons() {
	global $post;
?>
	<div class="share-button">
    
		<iframe src="http://www.facebook.com/plugins/like.php?href=<?php echo get_permalink($post->ID); ?>&amp;layout=button_count&amp;show_faces=true&amp;width=80&amp;action=like&amp;font&amp;colorscheme=light&amp;height=20" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:80px; height:20px; margin:0 5px 0 0;" allowTransparency="true"></iframe>
        
        <a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php echo get_permalink($post->ID); ?>"  data-hashtags="ThemeWarrior">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

		<!-- Place this tag where you want the +1 button to render -->
		<g:plusone size="medium"></g:plusone>
		
		<!-- Place this render call where appropriate -->
		<script type="text/javascript">
			(function() {
			var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
			po.src = 'https://apis.google.com/js/plusone.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
			})();
		</script>
	</div>
<?php
}

// Set post rating option
update_option($shortname . '_post_rating', 'Yes');
?>