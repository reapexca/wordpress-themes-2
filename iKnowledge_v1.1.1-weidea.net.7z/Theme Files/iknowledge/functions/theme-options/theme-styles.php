<?php
/**
 * Warrior Javascript & CSS
 *
 * Function to load Javascript and CSS 
 * for theme frontend
 */
function warrior_enqueue_scripts() {
	global $shortname, $pagenow;
	
	// Only load these scripts on frontend
	if( !is_admin() && $pagenow != 'wp-login.php' ) {
		
		// Load all Javascript files
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-datepicker');
		wp_enqueue_script('jquery-ui-tabs');
		wp_enqueue_script( 'superfish', get_template_directory_uri() .'/js/superfish.js', '', '1.4.8', true );
		wp_enqueue_script( 'mobilemenu', get_template_directory_uri() .'/js/jquery.mobilemenu.js', '', '1.0', true );
		wp_enqueue_script( 'functions', get_template_directory_uri() .'/js/functions.js', '', '1.0', true);
		
		// Load all CSS files		
		wp_enqueue_style('style', get_stylesheet_directory_uri() .'/style.css', array(), false, 'screen');
		wp_enqueue_style('superfish', get_template_directory_uri() .'/css/superfish.css', array(), false, 'screen');
		wp_enqueue_style('ui.tabs', get_template_directory_uri() .'/css/jquery.ui.tabs.css', array(), false, 'screen');
		wp_enqueue_style('ui.datepicker', get_template_directory_uri() .'/css/jquery.ui.datepicker.css', array(), false, 'screen');
		
		// Load CSS file for theme style
		if( get_option($shortname.'_style') <> "" ) {
			wp_enqueue_style($shortname.'_style', get_template_directory_uri() .'/styles/'. get_option($shortname.'_style').'/'.get_option($shortname.'_style').'.css', array(), false, 'screen');
		} else {
			wp_enqueue_style($shortname.'_style', get_template_directory_uri() .'/styles/default/default.css', array(), false, 'screen');
		}
		
		// Load custom CSS file
		wp_enqueue_style('custom', get_template_directory_uri() .'/custom.css', array(), false, 'screen');
		wp_enqueue_style('custom');
	}
}
add_action( 'init', 'warrior_enqueue_scripts' );


/**
 * Warrior Javascript & CSS
 *
 * Function to load inline 
 * Javascript and CSS files
 */
function warrior_js_css() {
	global $shortname;
?>
	<style type="text/css">
        /* Load custom styles defined in WarriorPanel */
		
		body,
		.widget .contributors h3.title,
		.articles h4.title,
		.warrior_tabs .list .title {
			font-family: <?php echo get_option($shortname.'_font'); ?>;
			}
		<?php if( get_option($shortname.'_font') == 'Verdana' || get_option($shortname.'_font') == 'Georgia' ) : ?>
		#footer { letter-spacing: -1px; }
 		<?php endif; ?>
		<?php if( get_option($shortname.'_color_text') != '' ) : ?>
		body { color: <?php echo get_option($shortname.'_color_text'); ?>; }
 		<?php endif; ?>
		<?php if( get_option($shortname.'_color_link') != '' ) : ?> 
		a:link { color: <?php echo get_option($shortname.'_color_link'); ?>; }
		<?php endif; ?>
		<?php if( get_option($shortname.'_color_hover') != '' ) : ?> 
		a:hover { color: <?php echo get_option($shortname.'_color_hover'); ?>; }
		<?php endif; ?>
		<?php if( get_option($shortname.'_color_visited') != '' ) : ?> 
		a:visited { color: <?php echo get_option($shortname.'_color_visited'); ?>; }
		<?php endif; ?>

		<?php
		$background = get_background_image();
		$color = get_background_color();
		if ( ! $background || ! $color ) :
			$style = $color ? "background-color: #$color;" : '';
			if ( $background ) {
				$image = " background-image: url('$background');";
				$repeat = get_theme_mod( 'background_repeat', 'repeat' );
					if ( ! in_array( $repeat, array( 'no-repeat', 'repeat-x', 'repeat-y', 'repeat' ) ) )
						$repeat = 'repeat';
					$repeat = " background-repeat: $repeat;";
				$position = get_theme_mod( 'background_position_x', 'left' );
					if ( ! in_array( $position, array( 'center', 'right', 'left' ) ) )
						$position = 'left';
					$position = " background-position: top $position;";
				$attachment = get_theme_mod( 'background_attachment', 'scroll' );
					if ( ! in_array( $attachment, array( 'fixed', 'scroll' ) ) )
						$attachment = 'scroll';
					$attachment = " background-attachment: $attachment;";
				$style .= $image . $repeat . $position . $attachment;
			}
			echo '.custom-background #footer .footer-area { '.trim( $style ).' }';
		endif;
		?>
		
	<?php if( get_option($shortname.'_style') <> "" ) :?>
		<?php echo get_option($shortname.'_custom_css'); ?>
	<?php endif; ?>
	
	<?php if( is_single() || is_page() ) : // Only load this styles when viewing single.php or page.php ?>
	/* -----------------------------------
		Print Styles 
	-----------------------------------*/
	@media print {
		* { 
			background: transparent !important; 
			font-family: Arial, Helvetica, sans-serif; 
			color: #444 !important; 
			text-shadow: none !important;
		}
		a {
			color: #265d7d !important;
		}
		#top,
		#header, 
		#leftcol-bg, 
		#leftcol,
		#rightcol .widget,
		#breadcrumb, 
		.meta-box, 
		.navigation, 
		#comments, 
		#respond, 
		#footer { 
			display:none; 
		}
		#rightcol {
			width:100%;
		}
		#rightcol.full-width .entry-content {
			width: 100%;
		}
	}
	<?php endif; ?>
	</style>
    
	<!--[if lte IE 6]>
		<link href="<?php bloginfo('template_url'); ?>/css/ie6.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/DD_belatedPNG_0.0.8a-min.js"></script>
		<script>
			DD_belatedPNG.fix('*');
			jQuery(document).ready(function(){
				function setEqualHeight(columns){
					var tallestcolumn = 0;
					columns.each(function(){
						currentHeight = jQuery(this).height();
						if (currentHeight > tallestcolumn){
							tallestcolumn  = currentHeight + 120;
						}
					});
					columns.height(tallestcolumn);
				}
				setEqualHeight(jQuery('#rightcol, #leftcol'));
			});
		</script>
	<![endif]-->
	<!--[if IE 7]>
		<link href="<?php echo get_template_directory_uri(); ?>/css/font-awesome-ie7.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo get_template_directory_uri(); ?>/css/ie7.css" rel="stylesheet" type="text/css" />
	<![endif]-->
	<!--[if IE 8]>
		<link href="<?php echo get_template_directory_uri(); ?>/css/ie8.css" rel="stylesheet" type="text/css" />
	<![endif]-->
<?php
}
add_action( 'wp_head', 'warrior_js_css' );
?>