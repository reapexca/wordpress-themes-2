<?php global $shortname; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<title><?php warrior_title(); ?></title>
<?php warrior_meta(); ?>

<?php if( get_option($shortname.'_maintenance_status') == 'No' || current_user_can('administrator') ): // Check if the site is in maintenance mod ?>
	<?php if ( get_option($shortname.'_ie6_warning') == "Yes" && strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 6.') == true) : ?>
		<?php wp_enqueue_style('ie6', get_template_directory_uri() .'/css/ie6-warning.css', array(), false, 'screen'); ?>
    <?php else: ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
        <?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
        <?php wp_head(); ?>
    <?php endif; ?>
<?php else: ?>
	<?php wp_enqueue_style('maintenance', get_template_directory_uri() .'/css/maintenance.css', array(), false, 'screen'); ?>
<?php endif; ?>
</head>

<body <?php body_class(); ?>>

<?php warrior_maintenance(); warrior_ie6_warning(); ?>

	<div id="top" class="clearfix">
		<div class="container">
			<!-- START: HEADER -->
			<div id="header" class="clearfix">
							
				<div class="logo">
					<?php warrior_logo(); ?>
				</div>
						
			</div>
			<!-- END: HEADER -->

			<!-- START: ACCESS -->
			<div id="access" class="clearfix">
				<?php if (has_nav_menu('top-menu')!='') : ?>
					<?php wp_nav_menu( array ( 'theme_location' => 'top-menu', 'menu_id' => 'main-menu', 'menu_class' => 'top-menu', 'container' => null, 'fallback_cb' => null ) ); ?>
				<?php endif; ?>
			</div>
			<!-- END: ACCESS -->
		</div>
	</div>
		
	<div id="main-content" class="container clearfix">
