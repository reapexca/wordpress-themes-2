<?php // Do not delete these lines
if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
	die (_e('Please do not load this page directly. Thanks!', 'warrior'));

	if (!empty($post->post_password)) { // if there's a password
		if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
?>
	<p class="nocomments"><?php _e('This post is password protected. Enter the password to view comments.','warrior') ; ?></p>
<?php
		return;
		}
	}
?>

<?php if ( have_comments() ) : ?>

    <!-- START: COMMENT LIST -->
    <div id="comments" class="clearfix">
        <h3 class="title"><?php comments_number(__('No Comment', 'warrior'), __('1 Comment', 'warrior'), __('% Comments', 'warrior') ); ?></h3>
    
        <ol class="commentlist">
            <?php wp_list_comments('avatar_size=70&callback=warrior_comment_list'); ?>
        </ol>
        
    </div>
    <!-- END: COMMENT LIST -->
    
    <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
        <div class="navigation clearfix">
            <span class="prev"><?php previous_comments_link(__('&larr; Previous', 'warrior'), 0); ?></span>
            <span class="next"><?php next_comments_link(__('Next &rarr;', 'warrior'), 0); ?></span>
        </div>	
    <?php endif; ?>
		
<?php else : // or, if we don't have comments:
	if ( ! comments_open() ) :
?>
<div class="wrapper">
</div>
	<?php endif; // end ! comments_open() ?>
		
<?php endif; // end have_comments() ?> 

	<!-- START: RESPOND -->
    <?php 
        $aria_req = ( $req ? " aria-required=\"true\"" : '' );
        comment_form( array(
            'title_reply'			=>	__( 'Leave a Comment','warrior' ),
            'comment_notes_before'	=>	'',
            'comment_notes_after'	=>	'',
            'label_submit'			=>	__( 'Submit','warrior' ),
            'fields'				=> array(
                'author'				=>	'<p class="comment-form-author">'."\n"
											.'<label for="author">Name</label>'."\n"
											.'<input id="author" name="author" type="text" size="30" value=""' . $aria_req . ' />'."\n"
											.'</p>',
                'email'					=>	'<p class="comment-form-email">'."\n"
											.'<label for="email">Email</label>'."\n"
											.'<input id="email" name="email" type="text" size="30" value=""' . $aria_req . ' />'."\n"
											.'</p>',
                'url'					=>	'<p class="comment-form-url">'."\n"
											.'<label for="url">Website</label>'."\n"
											.'<input id="url" name="url" type="text" size="30" value=""/>'."\n"
											.'</p>'
										),
            'comment_field'			=>	'<p class="comment-form-comment">'."\n"
										.'<label for="comment">Comment</label>'."\n"
										.'<textarea id="comment" rows="5" cols="45" aria-required="true" name="comment"></textarea>'."\n"
										.'</p>'
            ));
        ?>
 	<!-- END: RESPOND -->