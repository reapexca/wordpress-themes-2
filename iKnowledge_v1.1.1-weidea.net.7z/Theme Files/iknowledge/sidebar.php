<!-- START: LEFT COLUMN -->
<div id="leftcol" class="clearfix">
		
	<!-- START: SIDEBAR -->
	<div id="sidebar" class="clearfix">
					
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) {
			the_widget('WP_Widget_Categories', '', 'before_title=<h3 class=title>&after_title=</h3>&before_widget=<div class="widget widget_categories">&after_widget=</div>');
			the_widget('Warrior_Twitter', 'warrior_twitter_title=Latest Tweets&warrior_twitter_username=themewarrior&warrior_twitter_button_text=Follow Us on Twitter', 'before_title=<h3 class=title>&after_title=</h3>&before_widget=<div class="widget warrior_twitter">&after_widget=</div>');
			the_widget('Warrior_Author_List', 'warrior_author_list_title=Contributors', 'before_title=<h3 class=title>&after_title=</h3>&before_widget=<div class="widget warrior_author_list">&after_widget=</div>');
			the_widget('Warrior_Tabs', 'warrior_tabs_latest_posts_total=5&warrior_tabs_most_commented_total=5', 'before_widget=<div class="widget warrior_tabs">&after_widget=</div>');
			the_widget('WP_Widget_Text', 'title=Technical Support&text=<p>Has no porro reprehendunt. Eam ei quidam sanctus lobortis. Ut mel virtute repudiare, ridens feugait instructior at nec.</p><p>Phone: 021-5683215<br/>Fax: 021-5683212<br/>Email: support@localhost</p>', 'before_title=<h3 class=title>&after_title=</h3>&before_widget=<div class="widget widget_text">&after_widget=</div>');
		} ?>

		<div class="socialmedia">
			<?php warrior_social_icons(); ?>
		</div>
				
	</div>
	<!-- END: SIDEBAR -->

</div>
<!-- END: LEFT COLUMN -->