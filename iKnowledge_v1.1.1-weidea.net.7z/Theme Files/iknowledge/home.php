<?php get_header(); ?>

<!-- START: RIGHT COLUMN -->
<div id="rightcol" class="clearfix">
	<!-- START: CONTENT -->
	<div id="content" class="clearfix">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage') ) { } ?>
	</div>
	<!-- END: CONTENT -->
</div>
<!-- END: RIGHT COLUMN -->

<?php get_sidebar(); ?>
	
<?php get_footer(); ?>