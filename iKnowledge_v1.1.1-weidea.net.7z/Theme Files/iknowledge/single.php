<?php get_header(); ?>

<!-- START: RIGHT COLUMN -->
<div id="rightcol" class="clearfix">
			
	<!-- START: CONTENT -->
	<div id="content" class="clearfix">
			
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage') ) { } ?>
		<?php get_template_part('includes/breadcrumb' ); ?>
			
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			
			<div id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?>>
				<h1 class="title"><?php the_title(); ?><span></span></h1>
				
				<?php warrior_box_info(); ?>
					
				<div class="entry">
					<?php the_content(); ?>
					<?php wp_link_pages( array('before' => '<p><span>' . __('Pages:', 'warrior') .'</span>', 'after' => '</p>') ); ?>
					<?php the_tags(__('<p class="tags">', 'warrior'), '', '</p>'); ?>
				</div>
					
			</div>
				
		<?php endwhile; endif; ?>
			
		<?php comments_template( '', true ); ?>
			
	</div>
	<!-- END: CONTENT -->
		
</div>
<!-- END: RIGHT COLUMN -->

<?php get_sidebar(); ?>
	
<?php get_footer(); ?>