<?php get_header(); ?>

<!-- START: RIGHT COLUMN -->
<div id="rightcol" class="clearfix">
			
	<!-- START: CONTENT -->
	<div id="content" class="clearfix">
	
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage') ) { } ?>
		<?php get_template_part('includes/breadcrumb' ); ?>

		<?php
		if ( is_category() ) :
			echo '<h1 class="title">'.sprintf(__('Category: %s', 'warrior'), '<span>'.single_cat_title('', false).'</span>').'</h1>';
		elseif ( is_tag() ) :
			echo '<h1 class="title">'.sprintf(__('Tag: %s', 'warrior'), '<span>'.single_tag_title('', false).'</span>').'</h1>';
		elseif ( is_day() ) :
			echo '<h1 class="title">'.sprintf(__('Archive: %s', 'warrior'), '<span>'.get_the_time('F jS, Y').'</span>').'</h1>';
		elseif ( is_month() ) :
			echo '<h1 class="title">'.sprintf(__('Archive: %s', 'warrior'), '<span>'.get_the_time('F, Y').'</span>').'</h1>';
		elseif ( is_year() ) :
			echo '<h1 class="title">'.sprintf(__('Archive: %s', 'warrior'), '<span>'.get_the_time('Y').'</span>').'</h1>';
		elseif ( is_author() ) :
			echo '<h1 class="title">'.sprintf(__('Author: %s', 'warrior'), '<span>'.get_query_var('author_name').'</span>').'</h1>';
		else :
			echo '<h1 class="title">'.__('Archives', 'warrior').'</h1>';
		endif;
		?>

        <?php include( get_template_directory() . '/includes/posts.php' ); // Display posts ?>
		
	</div>
	<!-- END: CONTENT -->

</div>
<!-- END: RIGHT COLUMN -->

<?php get_sidebar(); ?>
	
<?php get_footer(); ?>