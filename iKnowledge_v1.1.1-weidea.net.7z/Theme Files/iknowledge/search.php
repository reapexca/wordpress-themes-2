<?php 
global $query_string;

function warrior_advance_search_filter_where( $where = '' ) {
	if ( isset($_GET['fromdate']) && $_GET['fromdate'] && $_GET['fromdate'] != 'From' ) $where .= " AND post_date >= '" . $_GET['fromdate'] . "'";
	if ( isset($_GET['todate']) && $_GET['todate'] && $_GET['todate'] != 'Until' ) $where .= " AND post_date <= '" . $_GET['todate'] . "'";
	return $where;
}

add_filter( 'posts_where', 'warrior_advance_search_filter_where' );
query_posts( $query_string );
remove_filter( 'posts_where', 'warrior_advance_search_filter_where' );
?>

<?php get_header(); ?>

<!-- START: RIGHT COLUMN -->
<div id="rightcol" class="clearfix">
			
	<!-- START: CONTENT -->
	<div id="content" class="clearfix">
	
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage') ) { } ?>
		
		<?php echo '<h1 class="title">'.sprintf(__('Search Results: %s', 'warrior'), '<span>'.$s.'</span>').'</h1>'; ?>
		
        <?php include( get_template_directory() . '/includes/posts.php' ); // Display posts ?>
		
	</div>
	<!-- END: CONTENT -->

</div>
<!-- END: RIGHT COLUMN -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>