<?php
/*
Template Name: Archives
*/
?>

<?php get_header(); ?>

<!-- START: RIGHT COLUMN -->
<div id="rightcol" class="clearfix">
            
    <!-- START: CONTENT -->
    <div id="content" class="clearfix">
            
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage') ) { } ?>
		<?php get_template_part('includes/breadcrumb' ); ?>

        <div class="hentry">
            <h1 class="title"><?php _e('Archives', 'warrior'); ?></h1>

            <?php warrior_box_info(); ?>

            <div id="archives">
                <div class="post">
                    <h3 class="title"><?php _e('Last 30 Posts', 'warrior'); ?></h3>
                    <ul>
                        <?php wp_get_archives('type=postbypost&limit=30'); ?>
                    </ul>
                </div>
                
                <div class="post">
                    <h3 class="title"><?php _e('Posts by Month', 'warrior'); ?></h3>
                    <ul>
                        <?php wp_get_archives('show_post_count=1'); ?>
                    </ul>
                </div>
                
                <div class="post">
                    <h3 class="title"><?php _e('Categories', 'warrior'); ?></h3>
                    <ul>
                        <?php wp_list_categories('title_li=&order_by=name&hide_empty=0') ?>
                    </ul>
                </div>
            </div>    
        </div>
            
    </div>
    <!-- END: CONTENT -->
        
</div>
<!-- END: RIGHT COLUMN -->

<?php get_sidebar(); ?>
    
<?php get_footer(); ?>