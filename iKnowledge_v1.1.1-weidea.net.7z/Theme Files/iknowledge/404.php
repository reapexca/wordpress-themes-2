<?php header("HTTP/1.1 404 Not Found"); ?>
<?php get_header(); ?>

<!-- START: RIGHT COLUMN -->
<div id="rightcol" class="clearfix">
			
	<!-- START: CONTENT -->
	<div id="content" class="clearfix">

		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage') ) { } ?>
		<?php get_template_part('includes/breadcrumb' ); ?>
		
		<div id="post-0" class="post error404 not-found hentry clearfix">
			<h1 class="title"><?php _e( 'Page Not Found', 'warrior' ); ?><span></span></h1>
			
			<div class="entry">
				<p><?php _e('The page you\'re looking for is not available. The page may have been deleted or the URL has changed. You can try searching the page with the search form.', 'warrior');?></p>
			</div>
			
		</div>

	</div>
	<!-- END: CONTENT -->

</div>
<!-- END: RIGHT COLUMN -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>