<?php get_header(); ?>
<?php get_sidebar(); ?>

<!-- START: RIGHT COLUMN -->
<div id="rightcol" class="clearfix">
			
	<!-- START: CONTENT -->
	<div id="content" class="clearfix">
	
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage') ) { } ?>
		<?php get_template_part('includes/breadcrumb' ); ?>

        <?php include( get_template_directory() . '/includes/posts.php' ); // Display posts ?>
		
	</div>
	<!-- END: CONTENT -->

</div>
<!-- END: RIGHT COLUMN -->
	
<?php get_footer(); ?>