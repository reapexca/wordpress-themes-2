<?php
/**
 * Warrior Functions
 * List of files inclusion and functions
 */

/*	define global variables :
	$themename : theme name information
	$shortname : short name information
	$warrior_panel_version : current version of the WarriorPanel
	$version : current theme version
	$options : an array that represent the general theme options
	$seo_options : an array that represent the general theme SEO options
*/

global $themename, $shortname, $version, $warrior_panel_version, $options, $theme_options, $seo_options;
	
$themename = 'iKnowledge';
$shortname = 'iknowledge';
$version = wp_get_theme()->Version;

require_once(TEMPLATEPATH . "/functions/warriorpanel/admin-init.php"); // Load WarriorPanel

require_once(TEMPLATEPATH . "/functions/theme-options/theme-options.php"); // Load options
require_once(TEMPLATEPATH . "/functions/theme-options/theme-widgets.php"); // Load widgets
require_once(TEMPLATEPATH . "/functions/theme-options/theme-support.php"); // Load theme support
require_once(TEMPLATEPATH . "/functions/theme-options/theme-functions.php"); // Load custom functions
require_once(TEMPLATEPATH . "/functions/theme-options/theme-styles.php"); // Load JavaScript, CSS & comment list layout

add_action( 'after_setup_theme', 'warrior_theme_init' );

function warrior_theme_init(){
	add_action( 'widgets_init', 'warrior_register_sidebars' );
	add_action( 'init', 'warrior_nav_menu' );
}

// Include Envato WordPress Toolkit Library
add_action('admin_init', 'themeforest_update_checker');

function themeforest_update_checker() {
	global $shortname;
	
	$themeforest_username = esc_html( get_option($shortname.'_tf_username') );
	$themeforest_api_key = esc_html( get_option($shortname.'_tf_api_key') );

	if ( $themeforest_username <> '' && $themeforest_api_key <> '' ) {
	    // include the library
	    include_once('envato-wordpress-toolkit-library/class-envato-wordpress-theme-upgrader.php');
	    
	    $upgrader = new Envato_WordPress_Theme_Upgrader( $themeforest_username, $themeforest_api_key );
	    $upgrader->check_for_theme_update(); 
	    $upgrader->upgrade_theme();
	}
}
?>