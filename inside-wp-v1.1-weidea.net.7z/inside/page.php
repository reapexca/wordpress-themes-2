<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<div class="container top_fix">
 
	<div id="content">
    
        <div <?php post_class(); ?>>
        
            <h1 class="singletitle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
        
        
            <div class="entry">
            
                <?php the_content(); ?>
                
                <?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:','themnific') . '</span>', 'after' => '</div>' ) ); ?>
                
                <?php the_tags( '<p class="tagssingle">','',  '</p>'); ?>
                
            </div>       
                    
            <div class="clearfix"></div>
               
            <p class="meta">
            
                <?php _e('on','themnific');?>  <?php the_time('F j'); ?> &bull; <?php _e('by','themnific');?> <?php the_author_posts_link(); ?>
            
            </p>
              
            <?php comments_template(); ?>
        
        </div>



	<?php endwhile; else: ?>

		<p><?php _e('Sorry, no posts matched your criteria','themnific');?>.</p>

	<?php endif; ?>

                <div class="clearfix"></div>

	</div><!-- #homecontent -->
        
</div>

<?php get_footer(); ?>