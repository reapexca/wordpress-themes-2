<div class="loop">
            <div class="fourcol first"> 
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer 1") ) : ?>
				<?php endif; ?>
            </div>
            
            
            <div class="fourcol">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer 2") ) : ?>
                <?php endif; ?>
            </div>
            
            <div class="fourcol"> 
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer 3") ) : ?>
                <?php endif; ?>
            </div>

</div>