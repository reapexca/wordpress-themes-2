<div id="services-wrap">
	<ul id="servicesbox">
    
		<?php $loop = new WP_Query( array( 'post_type' => 'service','posts_per_page' => 50) ); ?>
        <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
        <?php 
			$service_icon = get_post_meta($post->ID, 'themnific_aws_icon', true);
			$service_link = get_post_meta($post->ID, 'themnific_service_link', true);
		?>
        
            <li class="services body3 boxshadow2 rad">
            
				<?php if ( has_post_thumbnail()) : the_post_thumbnail('service'); endif; ?>
                
                <?php if($service_icon) {  echo ($service_icon); }?>
                
				<?php if ($service_link) { ?>
                
                	<h3><a href="<?php echo $service_link; ?>"><?php the_title(  ); ?></a></h3>
                    
  				<?php } else { ?>
                
					<h3><?php the_title(  ); ?></h3>
                    
				<?php } ?>       
                       
                <?php the_excerpt(); ?>
                
            </li>
        
        <?php endwhile; ?>
    
    </ul>
</div> 
<div style="clear: both;"></div>	