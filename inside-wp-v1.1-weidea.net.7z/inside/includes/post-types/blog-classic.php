           <div class="item_full item_blog item_height3 body3">
        
                <div class="imgwrap">
                
                        <span class="cats3"><?php the_time(get_option('date_format')); ?> &bull; <?php the_category(', ') ?></span>
                        
                        <a href="<?php the_permalink(); ?>">
                                
                            <?php the_post_thumbnail('blog'); ?>
                        
                        </a>
                        
                </div>	
    
                <h3><a href="<?php the_permalink(); ?>"><?php echo short_title('...', 12); ?></a></h3>
        
            </div>