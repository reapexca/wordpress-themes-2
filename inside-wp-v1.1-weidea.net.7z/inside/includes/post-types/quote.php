<li <?php post_class('boxshadow2'); ?>>
        
		<?php the_content(); ?>
        
        <p class="quuote_author"> &rdquo; <?php the_title(); ?> &rdquo; </p>
            
</li>