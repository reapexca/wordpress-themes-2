<li <?php post_class(); ?>>


	<?php
    $video_input = get_post_meta($post->ID, 'tmnf_video', true);
	$audio_input = get_post_meta($post->ID, 'tmnf_audio', true);
	$blog_featured = get_post_meta($post->ID, 'tmnf_blog_featured', true);
	?>
    
    <h2 class="singletitle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    
    
            
    <p class="meta fl">
    
        <?php the_category(', ') ?>  &bull;  
        
        <?php comments_popup_link( __('Comments (0)', 'themnific'), __('Comments (1)', 'themnific'), __('Comments (%)', 'themnific')); ?>
        
    </p> 
    
    
    
    <p class="meta fr">
    
        <span><?php _e('On','themnific');?></span> <?php the_time(get_option('date_format')); ?>  &bull; 
        <span><?php _e('By','themnific');?></span> <?php the_author_posts_link(); ?>
    
    </p>

	<?php 	if(has_post_format('video')){
                    echo ($video_input);
            }elseif(has_post_format('audio')){
                    echo ($audio_input);
					
			}elseif(has_post_format('gallery')){
				if ($blog_featured == 'Yes')  {
				   the_post_thumbnail('format-single');  
				} else;	
					
            } else { 
				if (get_option('themnific_post_image_dis') == 'true' );
				else {?>
				
					 <a href="<?php the_permalink(); ?>">  
						   <?php the_post_thumbnail('format-single');  ?>
					  </a>   
                      
     <?php } }?>
            
			<div class="clearfix"></div>
            
			<div class="clearfix"></div>

    		<div class="entry">    
            
				<?php global $more; $more = 0; ?>
                
                <?php the_content('Continue Reading'); ?> 
                  
           	</div>
                
            <a class="mainbutton" href="<?php the_permalink(); ?>"><?php _e('Read More','themnific');?> <i class="fa fa-arrow-circle-o-right"></i></a>
            
                  
</li>