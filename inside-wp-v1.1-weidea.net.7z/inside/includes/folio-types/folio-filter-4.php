           <?php
				$large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' ); 
				$large_image = $large_image[0]; 
				$project_url = get_post_meta($post->ID, 'themnific_project_url', true);
            ?>
            
            <div class="item_height2">
        
                <div class="imgwrap">
                
                        <div class="cats2">
    
                			<h3><a href="<?php the_permalink(); ?>"><?php echo short_title('...', 8); ?></a></h3>
                
                			<?php $terms_of_post = get_the_term_list( $post->ID, 'categories', '',' &bull; ', ' ', '' ); echo $terms_of_post; ?>
						
                        </div>
                        
                        <a href="<?php the_permalink(); ?>">
                                
                            <?php the_post_thumbnail('folio_4',array('title' => "")); ?>
                        
                        </a>
                        
                </div>	
                
                <a title="<?php _e('More Info','themnific');?>" class="hoverstuff-link rad" href="<?php the_permalink(); ?>"><i class="fa fa-caret-square-o-right"></i></a>
                
				<?php if($project_url) : ?>
                
                    <a target="_blank" title="<?php _e('Visit Project','themnific');?>" class="hoverstuff-zoom rad" href="<?php echo $project_url; ?>"><i class="fa fa-arrow-circle-o-right"></i></a>
                
                <?php endif; ?>
        
            </div>