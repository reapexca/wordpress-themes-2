           <?php
				$large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' ); 
				$large_image = $large_image[0]; 
				$another_image_1 = get_post_meta($post->ID, 'themnific_image_1_url', true);
				$video_input = get_post_meta($post->ID, 'themnific_video_url', true);
            ?>
            
            <div class="item_slider">
                        
                <a href="<?php the_permalink(); ?>">
                        
                    <?php the_post_thumbnail('folio_slider'); ?>
                
                </a>
                
                <div class="stuff2 body3 boxshadow3">
                
                    <h2><a href="<?php the_permalink(); ?>"><?php echo short_title('...', 8); ?></a></h2>
        
                    <p class="meta"><?php $terms_of_post = get_the_term_list( $post->ID, 'categories', '',' &bull; ', ' ', '' ); echo $terms_of_post; ?></p>
                    
                    <p><?php echo themnific_excerpt( get_the_excerpt(), '280'); ?></p>
                  
                    <a class="hoverstuff-link" href="<?php the_permalink(); ?>"><i class="icon-signout"></i></a>
        
        		</div>
        
            </div>