<?php get_header(); ?> 

    <div class="container top_fix"> 
        
            <div id="content">
                    <?php get_template_part('single-s-right' ); ?>
            </div><!-- #homecontent -->
    
    </div>

<?php get_footer(); ?>