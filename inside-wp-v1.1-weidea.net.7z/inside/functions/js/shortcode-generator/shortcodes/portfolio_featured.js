ShortcodeMeta={
	attributes:[
			{
				label:"Featured Portfolio",
				id:"category",
				help:"Enter category name (lowercase)."
			},
			{
				label:"Number of posts",
				id:"posts_number",
				help:"Enter number."
			},
			{
				label:"Columns",
				id:"columns",
				help:"Select number of columns.", 
				controlType:"select-control", 
				selectValues:['3', '4'],
				defaultValue: '3', 
				defaultText: '3 (Default)'
			}
			],
	defaultContent:"",
	shortcode:"portfolio_featured"
};
