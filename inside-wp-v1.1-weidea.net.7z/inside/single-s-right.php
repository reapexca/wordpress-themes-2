<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div <?php post_class('singlepost'); ?>> 
 
			<?php 
			$video_input = get_post_meta($post->ID, 'tmnf_video', true);
			$audio_input = get_post_meta($post->ID, 'tmnf_audio', true);
			$single_featured = get_post_meta($post->ID, 'tmnf_single_featured', true);
			?>

			<?php 	if(has_post_format('video')){
                  			echo ($video_input);
                 	}elseif(has_post_format('audio')){
                       		echo ($audio_input);
							
					
                    }elseif(has_post_format('gallery')){
						if ($single_featured == 'Yes')  {
                           the_post_thumbnail('format-single');  
						} else;	
							
                    } else {
						if (get_option('themnific_post_image_dis') == 'true' );
						else
                           the_post_thumbnail('format-single');  

                                
            }?>
			
            <div class="clearfix"></div>
            
            <h1 class="singletitle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
            
            <p class="meta">
            
            	<?php the_category(', ') ?>  &bull;  
                
                <?php comments_popup_link( __('Comments (0)', 'themnific'), __('Comments (1)', 'themnific'), __('Comments (%)', 'themnific')); ?>
            </p>

            <div class="entry">
            
            	<?php the_content(); ?>
            
            	<?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:','themnific') . '</span>', 'after' => '</div>' ) ); ?>
            
            </div>
            
            <p class="meta fl">
                <?php tmnf_breadcrumbs(); ?><br/>
            
            </p>
            
            <p class="meta fr">
                <?php the_tags( '<i class="fa fa-tags"></i>  ',', ',  ''); ?> &bull; 
                <i class="fa fa-clock-o"></i> <?php the_time(get_option('date_format')); ?>
            </p>
            
            <div class="clearfix"></div>
        
            <p class="meta clearfix">
            <?php previous_post_link('<span class="fl" style="width:45%;"><i class="fa fa-arrow-circle-o-left"></i> %link</span>'); ?>
            <?php next_post_link('<span class="fr" style="width:45%; text-align:right">%link <i class="fa fa-arrow-circle-o-right"></i></span>'); ?>
            </p> 
        
            <?php comments_template(); ?>

	<?php endwhile; else: ?>

		<p><?php _e('Sorry, no posts matched your criteria','themnific');?>.</p>

	<?php endif; ?>

    <div style="clear: both;"></div>

</div>