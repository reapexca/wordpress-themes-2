<?php get_header(); ?>
<?php
$large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' ); 
$large_image = $large_image[0]; 
$video_input = get_post_meta($post->ID, 'themnific_video_embed', true);
$project_url = get_post_meta($post->ID, 'themnific_project_url', true);
$featuredimage = get_post_meta($post->ID, 'themnific_fea_image', true);
$attachments = get_children( array('post_parent' => get_the_ID(), 'post_type' => 'attachment', 'post_mime_type' => 'image') );
?>

<?php the_post(); ?>
    
<div class="container top_fix">
    
    <h1 class="itemtitle"><?php the_title(); ?></h1>
    
	<?php if($project_url) : ?>
    
        <a class="mainbutton mainbutton_folio" href="<?php echo $project_url; ?>"><?php _e('Visit Project','themnific');?> <i class="fa fa-arrow-circle-o-right"></i></a>
    
    <?php endif; ?>
    
    
    <div class="nav_item">
        
        <?php previous_post_link('%link', '<i title="Previous Project" class="fa fa-arrow-circle-o-left"></i>') ?>
    
    	<a href="<?php echo stripslashes(get_option('themnific_url_portfolio'));?>"><i title="Back To Portfolio"  class="fa fa-arrow-circle-o-up"></i></a>
        
        <?php next_post_link('%link', '<i title="Next Project" class="fa fa-arrow-circle-o-right"></i>') ?>
	
    </div>
    
    <div class="clearfix"></div>
    

    
    <div id="foliocontent">   
            
            <?php if($video_input) { echo ($video_input); 

			} else {
				
				if($featuredimage == 'Yes')  { the_post_thumbnail('gallery_slider'); } 
				
    		 }?> 
             
                         
            
            <div class="entry entry_item">
             
				<?php the_content(); ?>
            
            </div>
            
           	<p class="folio_meta">
            	<?php $terms_of_post = get_the_term_list( $post->ID, 'categories', '',' &bull; ', ' ', '' ); echo $terms_of_post; ?> &bull; 
				<?php the_time(get_option('date_format')); ?>
			</p>
            
                
            <?php comments_template( '', true ); ?>
  
     </div>
     
</div>
        
<?php get_footer(); ?>