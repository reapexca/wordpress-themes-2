<?php get_header(); ?>

<div class="resmode-No section_template "
style="  <?php if(get_option('themnific_blog_image')) { ?>background-image:url(<?php echo esc_url(get_option('themnific_blog_image'));?>);<?php } else {}?> ">

	<div class="container">
    
		<?php if (have_posts()) : ?>
    
		<?php $post = $posts[0]; if (is_month()) { ?> 
        
    	<h2><?php the_time('F, Y'); ?></h2>
        
        <?php } ?>
		
	</div>

</div>


<div id="portfolio-filter" class="body3">
 
	<div class="container">
    
        <ul>
        
            <li><a class="current" href="<?php echo stripslashes(get_option('themnific_url_blog'));?>">
            
            <?php _e('All','themnific');?></a></li>
            
            <?php wp_list_categories('depth=1&title_li='); ?> 
            
        </ul>

	</div>

</div>

<div class="container"> 

    <div id="content">
    
      		<ul class="medpost">
          
    			<?php while (have_posts()) : the_post(); ?>
                                              		
            			<?php if(has_post_format('gallery'))  {
                            echo get_template_part( '/includes/post-types/medpost' );
                        }elseif(has_post_format('video')){
                            echo get_template_part( '/includes/post-types/medpost' );
                        }elseif(has_post_format('audio')){
                            echo get_template_part( '/includes/post-types/medpost' );
                        }elseif(has_post_format('image')){
                            echo get_template_part( '/includes/post-types/image' );
                        }elseif(has_post_format('link')){
                            echo get_template_part( '/includes/post-types/link' );
                        }elseif(has_post_format('quote')){
                            echo get_template_part( '/includes/post-types/quote' );
                            } else {
                            echo get_template_part( '/includes/post-types/medpost' );
                        }?>
                    
   				<?php endwhile; ?>   <!-- end post -->
                    
     		</ul><!-- end latest posts section-->
            
            <div style="clear: both;"></div>

					<div class="pagination"><?php tmnf_pagination('&laquo;', '&raquo;'); ?></div>

					<?php else : ?>
			

                        <h1>Sorry, no posts matched your criteria.</h1>
                        <?php get_search_form(); ?><br/>
					<?php endif; ?>

        </div><!-- end #homesingle-->
        
   
</div>
   

<?php get_footer(); ?>