<?php get_header(); ?>

<div class="resmode-No section_template "
style="  <?php if(get_option('themnific_blog_image')) { ?>background-image:url(<?php echo esc_url(get_option('themnific_blog_image'));?>);<?php } else {}?> ">

	<div class="container">
    
		<?php if (have_posts()) : ?>
    
		<h2><?php _e('Results for','themnific');?> "<?php echo $s; ?>"</h2>
		
	</div>

</div>


<div id="portfolio-filter" class="body3">
 
	<div class="container">
    
        <ul>
        
            <li><a class="current" href="<?php echo stripslashes(get_option('themnific_url_blog'));?>">
            
            <?php _e('All','themnific');?></a></li>
            
            <?php wp_list_categories('depth=1&title_li='); ?> 
            
        </ul>

	</div>

</div>

<div class="container"> 

    <div id="content">
    
      		<ul class="medpost">
          
    			<?php while (have_posts()) : the_post(); ?>
                                              		
            			<?php if(has_post_format('gallery'))  {
                            echo get_template_part( '/includes/post-types/medpost' );
                        }elseif(has_post_format('video')){
                            echo get_template_part( '/includes/post-types/medpost' );
                        }elseif(has_post_format('audio')){
                            echo get_template_part( '/includes/post-types/medpost' );
                        }elseif(has_post_format('image')){
                            echo get_template_part( '/includes/post-types/image' );
                        }elseif(has_post_format('link')){
                            echo get_template_part( '/includes/post-types/link' );
                        }elseif(has_post_format('quote')){
                            echo get_template_part( '/includes/post-types/quote' );
                            } else {
                            echo get_template_part( '/includes/post-types/medpost' );
                        }?>
                    
   				<?php endwhile; ?>   <!-- end post -->
                    
     		</ul><!-- end latest posts section-->
            
            <div style="clear: both;"></div>

					<div class="pagination"><?php tmnf_pagination('&laquo;', '&raquo;'); ?></div>

					<?php else : ?>
                    
						<!-- Not Found Handling -->
                        
                        <div class="hrlineB"></div>
                        
                        <h4><?php _e('Sorry, no posts matched your criteria.','themnific');?></h4>
                        
           				<h4><?php _e('Perhaps You will find something interesting form these lists...','themnific');?></h4>
                        
            			<div class="hrline"></div>
                        
						<?php get_template_part('/includes/uni-404-content');?>
                        
                        
					<?php endif; ?>

        </div><!-- end #homesingle-->

        <div id="sidebar"  class="fourcol">
               <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar") ) : ?>
               <?php endif; ?>
        </div><!-- #sidebar -->
        
   
</div>
   

<?php get_footer(); ?>