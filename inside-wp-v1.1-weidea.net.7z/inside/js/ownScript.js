jQuery(document).ready(function(){
/*global jQuery:false */
/*jshint devel:true, laxcomma:true, smarttabs:true */
"use strict";

	jQuery(window).scroll(function () { 
	
	   jQuery('.stuff').css({
		  'bottom' : -(jQuery(this).scrollTop()/3)+"px"
	   }); 
	
	});

	var $document = jQuery(document),
		$element = jQuery('#header'),
		className = 'header_scroll';
	
	$document.scroll(function() {
	  $element.toggleClass(className, $document.scrollTop() >= 200);
	});


	// add header class on mobile screens
	jQuery(function() {
	/* Check width on page load*/
		if ( jQuery(window).width() < 769) {
			 jQuery('#header').addClass('header_scroll');
			}
		else {}
	});
	  
	jQuery(window).resize(function() {
	/*If browser resized, check width again */
		if (jQuery(window).width() < 769) {
			 jQuery('#header').addClass('header_scroll');
			}
		else {jQuery('#header').removeClass('header_scroll');}
	});


	// add nav current class on load
	jQuery(function() {
		jQuery('#nav li:first').addClass('current');
	});
	
	// initiate page scroller plugin	
	jQuery('.scroll').onePageNav({
		begin: function() {
		console.log('start');},
		end: function() {
		console.log('stop');},
		filter: ':not(.external a)'
	});


	// add spec class to nav
	jQuery("ul.sub-menu,ul.children").parents().addClass('scrollparent');

	// parallax
	jQuery('.section').parallax("50%", 0.05);
	jQuery('.section_template').parallax("50%", 0.6);
	
	 if (jQuery.browser.webkit) {
			jQuery(".section").css('background-attachment','scroll');
			jQuery('.section').parallax("50%", 0.23);
    }


	// trigger + show menu on fire
	  jQuery(window).resize(function() {
	  /*If browser resized, check width again */
		  if (jQuery(window).width() < 639) {
			   jQuery('#navigation').addClass('hidenav');
			   jQuery('a#navtrigger').addClass('showtrig');
			  }
		  else {
			  jQuery('#navigation').removeClass('hidenav');
			  jQuery('a#navtrigger').removeClass('showtrig');}
	  });
	  
        jQuery('a#navtrigger').click(function(){ 
                jQuery('#navigation').toggleClass('shownav'); 
                jQuery('#sec-nav').toggleClass('shownav'); 
                jQuery(this).toggleClass('active'); 
                return false; 
        });

	// fading out/in slider stuff
	var fadeStart=100 // 100px scroll or less will equiv to 1 opacity
		,fadeUntil=500 // 500px scroll or more will equiv to 0 opacity
		,fading = jQuery('.stuff,#header_bottom,.section_template h2')
	;
	
	jQuery(window).bind('scroll', function(){
		var offset = jQuery(document).scrollTop()
			,opacity=0
		;
		if( offset<=fadeStart ){
			opacity=1;
		}else if( offset<=fadeUntil ){
			opacity=1-offset/fadeUntil;
		}
		fading.css('opacity',opacity);
	});


	/* Tooltips */
	jQuery("body").prepend('<div class="tooltip rad"><p></p></div>');
	var tt = jQuery("div.tooltip");
	
	jQuery(".flickr_badge_image a img,ul.social-menu li a,.nav_item i,a.hoverstuff-zoom,a.hoverstuff-link,#ssba img").hover(function() {								
		var btn = jQuery(this);
		
		tt.children("p").text(btn.attr("title"));								
					
		var t = Math.floor(tt.outerWidth(true)/2),
			b = Math.floor(btn.outerWidth(true)/2),							
			y = btn.offset().top - 30,
			x = btn.offset().left - (t-b);
					
		tt.css({"top" : y+"px", "left" : x+"px", "display" : "block"});			
		   
	}, function() {		
		tt.hide();			
	});



	function lightbox() {
		// Apply PrettyPhoto to find the relation with our portfolio item
		jQuery("a[rel^='prettyPhoto']").prettyPhoto({
			// Parameters for PrettyPhoto styling
			animationSpeed:'fast',
			slideshow:5000,
			theme:'pp_default',
			show_title:false,
			overlay_gallery: false,
			social_tools: false
		});
	}
	
	if(jQuery().prettyPhoto) {
		lightbox();
	}

});