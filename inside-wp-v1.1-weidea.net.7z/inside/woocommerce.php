<?php get_header(); ?>

<div class="container top_fix">
 
	<div id="content">
    
		<?php woocommerce_content(); ?>

		<div class="clearfix"></div>

	</div><!-- #homecontent -->
        
</div>

<?php get_footer(); ?>