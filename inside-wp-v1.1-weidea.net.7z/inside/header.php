<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="utf-8" />
<title><?php global $page, $paged; wp_title( '|', true, 'right' ); bloginfo( 'name' ); $site_description = get_bloginfo( 'description', 'display' ); echo " | $site_description"; if ( $paged >= 2 || $page >= 2 ) echo ' | ' . sprintf( __( 'Page %s','themnific'), max( $paged, $page ) ); ?></title>

<!-- Set the viewport width to device width for mobile -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php themnific_head(); ?>

<?php wp_head(); ?>

</head>

     
<body <?php if (get_option('themnific_upper') == 'false' ){ body_class( );} else body_class('upper' ) ?>>

<?php if (get_option('themnific_wrap') == 'false' ); else echo '<div class="container_wrap container_shadow">'; ?>

<div id="header">

	<div class="container-out boxshadow2 clearfix" style="overflow:visible;"> 
    
        <div class="container" style="overflow:visible;">
        
            <?php if(get_option('themnific_logo')) { ?>
                            
                <a href="<?php echo home_url(); ?>/">
                
                    <img id="logo" src="<?php echo esc_url(get_option('themnific_logo'));?>" alt="<?php bloginfo('name'); ?>"/>
                        
                </a>
                    
            <?php } 
                    
                else { ?> <h1><a href="<?php echo home_url(); ?>/"><?php bloginfo('name');?></a></h1>
                    
            <?php } ?>
        
            <a id="navtrigger" href="#"><?php _e('MENU','themnific');?></a>
    
            <nav id="navigation">
    
                <?php	if(is_page_template('homepage.php'))  { 
                
                    get_template_part('/includes/home-navigation');
                            
                        } else {
                           
                    get_template_part('/includes/uni-navigation');
                    
                }?>
                
            </nav>       
                
        </div><!-- end .container -->
    
    </div><!-- end .container-out -->
            
</div><!-- end #header -->

<div class="clearfix"></div>