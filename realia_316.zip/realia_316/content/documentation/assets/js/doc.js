$(document).ready(function() {
	$('.sidebar .nav').affix()
});