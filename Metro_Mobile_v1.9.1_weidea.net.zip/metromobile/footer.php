
        <?php 
		$options = get_option('metromobile_options');
		if(isset($options['disable_analytic']) == NULL){$disable_analytic = "0";}else{$disable_analytic = $options['disable_analytic'];}
		if(isset($options['custom_analytic']) == NULL){$custom_analytic = "0";}else{$custom_analytic = $options['custom_analytic'];}
		     
		if($disable_analytic != "1"){
		?>
		<script>
            var _gaq=[['_setAccount','<?php echo $custom_analytic ?>'],['_trackPageview']];
            (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
            g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
            s.parentNode.insertBefore(g,s)}(document,'script'));
        </script>
        
        <?php } ?>
        <?php wp_footer(); ?>
    </body>
</html>