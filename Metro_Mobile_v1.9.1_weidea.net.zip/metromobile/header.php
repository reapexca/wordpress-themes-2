<?php 
$page = get_page_by_title($post->post_title);
if(isset($page) <> NULL){$page_ID = $page->ID;}else{$page_ID = "";}
$options = get_option('metromobile_options');
?><!DOCTYPE html <?php language_attributes(); ?>>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]> <html class="no-js"> <![endif]-->
    <head>
    	
        <meta charset="utf-8">
        <!--[if IE]> <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
        <title><?php if(is_home()) bloginfo('name'); else wp_title(''); ?></title>
        <meta name="description" content="<?php echo $options['custom_desc'] ?>">
        <meta name="keywords" content="<?php echo $options['custom_keyw'] ?>">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> -->
        <meta content="initial-scale=1.0, user-scalable=no" name="viewport">
		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
        <?php 
            if(isset($options['theme_rtl_select']) != NULL){$theme_rtl_select = $options['theme_rtl_select'];}else{$theme_rtl_select = "0";};
			if($theme_rtl_select == 1){
		?>
		<style>body{text-align:right !important;}</style>
        <?php } ?>
        <!-- Splash screens -->
			<?php 
            if(isset($options['custom_splash_screen']) != NULL or $options['custom_splash_screen'] != ""){$custom_splash_screen = $options['custom_splash_screen'];}else{$custom_splash_screen = "";};
            if(isset($options['custom_splash_screen2']) != NULL or $options['custom_splash_screen2'] != ""){$custom_splash_screen2 = $options['custom_splash_screen2'];}else{$custom_splash_screen2 = "";};
			if(isset($options['custom_splash_screen3']) != NULL or $options['custom_splash_screen3'] != ""){$custom_splash_screen3 = $options['custom_splash_screen3'];}else{$custom_splash_screen3 = "";};
			if(isset($options['custom_splash_screen4']) != NULL or $options['custom_splash_screen4'] != ""){$custom_splash_screen4 = $options['custom_splash_screen4'];}else{$custom_splash_screen4 = "";};
			if(isset($options['custom_splash_screen5']) != NULL or $options['custom_splash_screen5'] != ""){$custom_splash_screen5 = $options['custom_splash_screen5'];}else{$custom_splash_screen5 = "";};
			if(isset($options['custom_splash_screen6']) != NULL or $options['custom_splash_screen6'] != ""){$custom_splash_screen6 = $options['custom_splash_screen6'];}else{$custom_splash_screen6 = "";};
			if(isset($options['custom_splash_screen7']) != NULL or $options['custom_splash_screen7'] != ""){$custom_splash_screen7 = $options['custom_splash_screen7'];}else{$custom_splash_screen7 = "";};
            ?>
			<!-- iPhone 320x460 -->
            <link href="<?php echo $custom_splash_screen;?>" media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 1)" rel="apple-touch-startup-image">
            <!-- iPhone (Retina) 640x920 -->
            <link href="<?php echo $custom_splash_screen2;?>" media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
            <!-- iPhone 5 640x1096-->
            <link href="<?php echo $custom_splash_screen3;?>" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
            <!-- iPad 768x1004 / 748x1024-->
            <link href="<?php echo $custom_splash_screen4;?>" media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 1)" rel="apple-touch-startup-image">
            <link href="<?php echo $custom_splash_screen5;?>" media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 1)" rel="apple-touch-startup-image">
            <!-- iPad (Retina) 1536x2008 / 1496x2048 -->
            <link href="<?php echo $custom_splash_screen6;?>" media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
            <link href="<?php echo $custom_splash_screen7;?>" media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
  		<!-- / Splash Screens -->
        
    	<?php
		//Custom BG
		if(isset($options['custom_bgphoto']) != NULL or $options['custom_bgphoto'] != ""){
			$custombgimg = "<style>";
			$custombgimg .= "body{background-image: url(".$options['custom_bgphoto']."); background-repeat: repeat;}";
			$custombgimg .= "</style>";
		echo $custombgimg;
		}
		//Theme set 
		if(isset($options['theme_outside']) == NULL or $options['theme_outside'] != "light"){wp_enqueue_style('bootstrapdark');}else{wp_enqueue_style('bootstrapwhite');}
		
		//Enque Styles and scripts
		wp_enqueue_style('camera'); 
		wp_enqueue_style('tiles'); 
		wp_enqueue_style('styles'); 
		wp_enqueue_style('fontawesome'); 
		wp_enqueue_style('NextGEN');
				
		// add jquery starts
		wp_enqueue_script('jquery');
		wp_enqueue_script('camera');
		wp_enqueue_script('bootstrap');
		wp_enqueue_script('spinner');
		wp_enqueue_script('jqmobile');
		wp_enqueue_script('easing');
		wp_enqueue_script('custom');
		wp_enqueue_script('modernzr');
		wp_enqueue_script('zepto');
		if(isset($options['theme_loadingani']) == NULL or $options['theme_loadingani'] == "yes"){ wp_enqueue_script('loadanim');}
		
		?>
        <!--[if IE]><link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/font-awesome-ie7.css"><![endif]-->
        <!-- You can put your own logo below linking photos for splash screen-->
        <?php if($options['custom_home_icon']!= "" or $options['custom_home_icon']!= NULL){ ?>
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $options['custom_home_icon']; ?>">
        <?php } ?>
        <?php if($options['custom_favico']!= "" or $options['custom_favico']!= NULL){ ?>
        <link rel="shortcut icon" href="<?php echo $options['custom_favico']; ?>">
        <?php } ?>
       
		<!-- / Mobile Tags -->
        <?php add_theme_support('automatic-feed-links'); ?>
        <?php 
		if(isset($options['general_bubble']) == NULL){$general_bubble = "0";}else{$general_bubble = $options['general_bubble'];}
		if( $general_bubble != "1"){
		?>
        <!--Add Home Bubble -->
		<?php if(is_home() == "1" or $options['homepage_page_select'] == $page_ID){wp_enqueue_script('add2home'); wp_enqueue_style('add2home');}; ?>
        <!--/Add Home Bubble-->
        <?php }; ?>
        
        <?php wp_head() ?>
    </head>
    <body  <?php body_class(); ?>>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an outdated browser. <a href="http://browsehappy.com/">Upgrade your browser today</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to better experience this site.</p>
    <![endif]-->
	<div style="display:none"><?php wp_nav_menu(); ?></div>
    <!-- This code is taken from http://twitter.github.com/bootstrap/examples/hero.html -->
    <!-- Loading Message -->
    <?php if(isset($options['theme_loadingani']) == NULL or $options['theme_loadingani'] == "yes"){ ?>
    <div class="spinnerbg">
    <div id="spinner">
        <span id="first" class="ball"></span>
        <span id="second" class="ball"></span>
        <span id="third" class="ball"></span>
    </div>
    </div>
    <!-- /Loading Message -->
    <?php } ?>