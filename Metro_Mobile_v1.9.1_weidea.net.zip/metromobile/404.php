<?php get_header(); ?>
		

            <div class="wrapper">       
                <div class="scrollable">
					<header>
                            <h1><?php the_title(); ?></h1>
                            <a href="<?php echo home_url(); ?>" class="back-button linkbut"></a>
                            <div class="line"></div>
                    </header>
             
                    <div class="MiddleContent">
                        	<h1><?php _e('Not Found', 'metromobile');?></h1>
                            <p><?php _e('Sorry, but the page you were trying to view does not exist.', 'metromobile');?></p>
                            <p><?php _e('It looks like this was the result of either:', 'metromobile');?></p>
                            <ul>
                                <li><?php _e('a mistyped address', 'metromobile');?></li>
                                <li><?php _e('an out-of-date link', 'metromobile');?></li>
                            </ul>
                    </div>
                </div>
             </div>


<?php get_footer(); ?>