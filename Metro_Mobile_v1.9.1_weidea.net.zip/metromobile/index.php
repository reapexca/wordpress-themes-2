<?php get_header(); ?>
<?php
$page = get_page_by_title($post->post_title);
if(isset($page) <> NULL){$page_ID = $page->ID;}else{$page_ID = "";}

$options = get_option('metromobile_options');

	
$query = new WP_Query( 'page_id='.$options['homepage_page_select'] );
?>    
        <?php while ($query->have_posts()) : $query->the_post(); ?>
        	<div class="wrapper">
               	<div class="scrollable">
                	<div class="webbutiles">
                    <?php the_content(); ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
            
<?php get_footer(); ?>