<?php 
get_header(); 
$options = get_option('metromobile_options');
?>
<script src="<?php echo get_template_directory_uri()?>/js/groovy.js"></script>

	<?php if (have_posts()){ ?>
    
        <?php while (have_posts()) : the_post(); ?>
                <!--START BLOG POSTS-->
               <div class="wrapper">       
                <div class="scrollable">
					<header>
                            <a href="javascript:history.back(-1)" class="back-button linkbut"></a>
                            <a href="<?php echo home_url(); ?>" class="home-button linkbuthome"></a>
                            <div class="line2"></div>
                    </header>
                    <div class="MiddleContent">
                        
                    <!--START POST-->
                    <div class="post-single">	
                        
                        
                        <!--START POST-TITLE-->
                        <div class="post-title">				
                            <h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                            <?php 
							if(isset($options['blog_category_check']) == NULL){$blog_category_check = "0";}else{$blog_category_check = $options['blog_category_check'];}
							if(isset($options['blog_author_check']) == NULL){$blog_author_check = "0";}else{$blog_author_check = $options['blog_author_check'];}
							if(isset($options['blog_date_check']) == NULL){$blog_date_check = "0";}else{$blog_date_check = $options['blog_date_check'];}
							if(isset($options['blog_comment_check']) == NULL){$blog_comment_check = "0";}else{$blog_comment_check = $options['blog_comment_check'];}
							
							if($blog_category_check== "1" and $blog_author_check== "1"){?>
                            <?php }else{ ?>
                            <span class="pauthor"><?php if($blog_category_check!= "1"){ the_category(); }?><?php if($blog_author_check!= "1"){?> <?php _e('posted by', 'metromobile');?> <?php the_author(); ?><?php }?> </span> 
                            <?php }?>
                        </div>
                        <!--END POST-TITLE-->
                        
                        <?php if ( has_post_thumbnail() ) {?>
                        <!--START POST-MEDIA-->
                        <div class="post-media">		
                            <a href="#"><?php the_post_thumbnail('large'); ?></a>
                        </div>
                        <!--END POST-MEDIA-->
                        <?php } ?>
                        
                        <?php if($blog_date_check== "1" and $blog_comment_check== "1"){?>
                        <div class="clear"></div>
                        <?php }else{ ?>
                        <!--START POST-INFO-->
                       <div class="post-info"> 	
                            <?php if($blog_date_check!= "1"){?>	
                            <div class="date badge badge-important"><i class="icon-calendar"></i> <?php the_time('F jS, Y') ?></div>
                            <?php }?>
                            <?php if($blog_comment_check!= "1"){?>					
                            <div class="comments badge"><i class="icon-comment"></i> <?php comments_popup_link(); ?></div>	
                            <?php }?>						
                        </div>
                        <!--END POST-INFO-->	
                        <?php }?>
                        
                        <!--START POST-CONTENT -->
                        <div class="post-content">	
                        
                           <?php the_content(); ?>
                            
                        
                        </div>
                        <!--END POST-CONTENT -->
                    
                    </div>
                    <!--END POST-->
                    
                	<?php 
					if($blog_comment_check != "1" and get_comments_number() > 0){?>
                    <!--START COMMENTS-->
              
                        <?php comments_template(); ?>   
                  
                    <!--END COMMENTS-->
                   <?php }?>
                   
                   <?php if($blog_comment_check != "1"){?>
					<!--START COMMENT FORM-->

					<?php comment_form(); ?>  
              
                    <!--END COMMENT FORM--> 
                   <?php }?>
                     
                </div>
            </div>
         </div>
                <!--END BLOG POSTS-->

        <?php endwhile; ?>
        
      <?php } else { ?>

        		<div class="mainbox">
                <p><?php _e('Sorry, no posts matched your criteria.', 'metromobile');?></p>
				</div>

        
		<?php } ?>
   
<?php get_footer(); ?>