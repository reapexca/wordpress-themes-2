<?php 
get_header(); 
?>

	<?php
		  if (have_posts()) : while (have_posts()) : the_post();
		  ?>
                <div class="wrapper">       
                <div class="scrollable">
					<header>
                            <a href="javascript:history.back(-1)" class="back-button linkbut"></a>
                            <a href="<?php echo home_url(); ?>" class="home-button linkbuthome"></a>
                            <div class="line2"></div>
                    </header>
                    <div class="MiddleContent">
                    <!--START POST-->
                    <div class="post">	
                        <!--START POST-TITLE-->
                        <div class="post-title">				
                            <h2 class="title"><?php the_title(); ?></h2>
                        </div>
                        <!--END POST-TITLE-->
                        
                        <!--START POST-CONTENT -->
                        <div class="post-content">	
                        
                           <?php the_content(); ?>
                            
                        
                        </div>
                        <!--END POST-CONTENT -->
                    
                    </div>
                    <!--END POST-->
                    
                	
                </div>
                <!--END BLOG POSTS-->

                </div>
            </div>
         </div>

        <?php endwhile; else: ?>

        		<div class="wrapper">       
                <div class="scrollable">
					<header>
                            <a href="javascript:history.back(-1)" class="back-button linkbut"></a>
                            <a href="<?php echo home_url(); ?>" class="home-button linkbuthome"></a>
                            <div class="line2"></div>
                    </header>
                    <div class="MiddleContent">
                <p><?php _e('Sorry, no posts matched your criteria.', 'metromobile');?></p>

                </div>
              </div>
        	 </div>
        
		<?php
		  endif;
		?>
   
<?php get_footer(); ?>