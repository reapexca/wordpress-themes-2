

    <div class="post-single">
    <?php
	  if ( !empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) :
	?>
    <p><?php _e('Enter your password to view comments.', 'metromobile'); ?></p>
    <?php return; endif; ?>
    <h3 class="title"><i class="icon-comment"></i> <?php comments_number(); ?>
    <?php if ( comments_open() ) : ?>
        <a href="#postcomment" title="<?php _e('Leave a comment', 'metromobile'); ?>"></a>
    <?php endif; ?></h3>		
        
        
    
        <?php if ( $comments ) : ?>
        <!-- START COMMENT-LIST -->
        <div class="commentlist"><?php wp_list_comments(array('style' => 'div')); ?></div>
        <!-- END COMMENT-LIST -->
        <?php previous_comments_link(); ?> <?php paginate_comments_links(); ?> <?php next_comments_link(); ?> 
       
        <?php if ( is_singular() ) wp_enqueue_script( "comment-reply" ); ?>
        <?php else : // If there are no comments yet ?>
            <p><i class="icon-comment"></i> <?php  _e('No comments yet.', 'metromobile'); ?></p>
        <?php endif; ?>
            
    </div>
    <!--END POST-->     