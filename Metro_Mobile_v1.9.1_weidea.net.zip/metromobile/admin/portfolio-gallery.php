<?php
add_theme_support( 'post-thumbnails' ); 
if ( function_exists( 'add_image_size' ) ) { 
	add_image_size( 'portfolio-image', 1024, 695, true );
};
function webbu_portfolio_page_init() {
  $labels = array(
    'name' => 'Portfolio Items', 'Portfolio_Items',
    'singular_name' => 'Portfolio Items', 'webbuportfolio',
    'add_new' => 'Add New', 'slideritem',
    'add_new_item' => 'Add New Portfolio Item',
    'edit_item' => 'Edit Portfolio Item',
    'new_item' => 'New Portfolio Item',
    'all_items' => 'All Portfolio Items',
    'view_item' => 'View Portfolio Item',
    'search_items' => 'Search Portfolio Items',
    'not_found' =>  'No slide item found',
    'not_found_in_trash' => 'No slide item found in Trash', 
    'parent_item_colon' => '',
    'menu_name' => 'Portfolio Items'

  );
  $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true, 
    'show_in_menu' => true, 
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'has_archive' => true, 
    'hierarchical' => false,
    'menu_position' => 120,
    'supports' => array('title', 'excerpt', 'editor', 'revisions', 'thumbnail')
  ); 
  register_post_type('webbuportfolio',$args);
}
add_action( 'init', 'webbu_portfolio_page_init' );

?>