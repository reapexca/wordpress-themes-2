<?php
function get_portfolio_page(){
	$options = get_option('metromobile_options');
?>	<div class="mainbox">
	
	<?php 
	
		if(isset($options['custom_post_number_portfolio']) == NULL){$custom_post_number_portfolio = "0";}else{$custom_post_number_portfolio = $options['custom_post_number_portfolio'];}		
		if(isset($options['portfolio_column']) == NULL){$portfolio_column2 = "0";}else{$portfolio_column2 = $options['portfolio_column'];}
		if(isset($catshowopt) == NULL){$catshowopt = "1";}	
		
		$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		
		if($custom_post_number_portfolio == "" ){$catshowopt = $catshowopt.'&posts_per_page=9&paged='.$paged.'';}else{$catshowopt = $catshowopt.'&posts_per_page='.$custom_post_number_portfolio.'&paged='.$paged.'';}
		
		$catshowopt = $catshowopt.'&post_type=webbuportfolio';  
		
		$webbuloop = new wp_query( $catshowopt );
		
		$portfolio_column = $portfolio_column2;
		if($portfolio_column == ""){$portfolio_column = "portfolio-three";}
		
		if( $webbuloop->have_posts() ):
    ?>

    <!--  Column Gallery -->         
    <ul id="Portfolio" class="portfolio">
       <?php
            if ( $webbuloop->have_posts() ) : while ( $webbuloop->have_posts() ) : $webbuloop->the_post(); ?>
            <li class="<?php echo $portfolio_column;?>"> 
                <a href="<?php the_permalink()?>" title="<?php the_title_attribute(); ?>">
                <?php the_post_thumbnail('large'); ?>
                <p><strong><?php the_title_rss(); ?></strong><br><?php the_excerpt_rss(); ?></p>
                </a>
            </li>    
        <?php endwhile; rewind_posts(); endif; ?> 
    </ul>
    <!-- / Column Gallery --> 
    </div>
    
    <?php endif; ?> 
   
    <!--START PAGENAVI-->
    <div class="pagination pagination-centered">	
    <?php
    $big = 999999999; 
    
    echo custom_paginate_links( array(
    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
    'format' => '?paged=%#%',
    'current' => max( 1, get_query_var('paged') ),
    'total' => $webbuloop->max_num_pages
    ) );
    ?>		
    </div>
    <!--END PAGENAVI-->

<?php
	}

function get_blog_page(){
	$options = get_option('metromobile_options');
?>
    <!--START BLOG POSTS-->
    <!--START POST-->
    <?php
        // Show custom category posts
		if(isset($options['blog_category_id']) == NULL){
			$blog_category_id = "0";
		}else{
			$blog_category_id = $options['blog_category_id'];
		}
		
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
			if(isset($options['blog_category_show']) == NULL){
			$blog_category_show = "0";
			}else{
			$blog_category_show = $options['blog_category_show'];
			}
          if ($blog_category_show != 1 ){
              $catshowopt = 'cat='.$blog_category_id.'';
          }else{
              $catshowopt = "";
              }
			  
		  if(isset($options['custom_post_number']) == NULL){
		    $custom_post_number = "0";
		  }else{
		    $custom_post_number = $options['custom_post_number'];
		  }
          if($custom_post_number == NULL or $custom_post_number == "" ){
              $catshowopt = $catshowopt.'&posts_per_page=5&paged='.$paged.'';
          }else{
              $catshowopt = $catshowopt.'&posts_per_page='.$custom_post_number.'&paged='.$paged.'';
              }
              
        
        $my_query = new WP_Query($catshowopt); 
        
        ?>
        
            <?php if( $my_query->have_posts() ) : ?>
        
                <?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
                    <?php
                    //necessary to show the tags 
                    global $wp_query;
                    $wp_query->in_the_loop = true;
                    ?>
                    <div class="post mainbox" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>	
                    <div class="inside_content">
                        <!--START POST-TITLE-->
                        <div class="post-title">				
                            <h2 class="title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                            <?php
							if(isset($options['blog_category_check']) == NULL){$blog_category_check = "0";}else{$blog_category_check = $options['blog_category_check'];}
							if(isset($options['blog_author_check']) == NULL){$blog_author_check = "0";}else{$blog_author_check = $options['blog_author_check'];}
							if(isset($options['blog_date_check']) == NULL){$blog_date_check = "0";}else{$blog_date_check = $options['blog_date_check'];}
							if(isset($options['blog_comment_check']) == NULL){$blog_comment_check = "0";}else{$blog_comment_check = $options['blog_comment_check'];}
							
							if($blog_category_check== "1" and $blog_author_check== "1"){?>
                            <?php }else{ ?>
                            <span class="pauthor"><?php if($blog_category_check!= "1"){ the_category(); }?><?php if($blog_author_check!= "1"){?> <?php _e('posted by', 'metromobile');?> <?php the_author(); ?><?php }?> </span> 
                            <?php }?>
                        </div>
                        <!--END POST-TITLE-->
                        
                        <?php if ( has_post_thumbnail() ) {?>
                        <!--START POST-MEDIA-->
                        <div class="post-media">		
                            <a href="<?php the_permalink()?>"><?php the_post_thumbnail('large'); ?></a>
                        </div>
                        <!--END POST-MEDIA-->
                        <?php } ?>
                        
                        <?php if($blog_date_check== "1" and $blog_date_check== "1"){?>
                        <div class="clear"></div>
                        <?php }else{ ?>
                        <!--START POST-INFO-->
                        <div class="post-info"> 	
                            <?php if($blog_date_check!= "1"){?>	
                            <div class="date badge badge-important"><i class="icon-calendar"></i> <?php the_time('F jS, Y') ?></div>
                            <?php }?>
                            <?php if($blog_comment_check!= "1"){?>					
                            <div class="comments badge"><i class="icon-comment"></i> <?php comments_popup_link(); ?></div>	
                            <?php }?>						
                        </div>
                        <!--END POST-INFO-->	
                        <?php }?>
                        
                        <!--START POST-CONTENT -->
                        <div class="post-content">	
                        
                        <?php the_content(); ?>
                        <a href="<?php the_permalink()?>" title="Permanent Link to <?php the_title_attribute(); ?>" class="more-link"><?php _e('Continue reading', 'metromobile');?> <i class="icon-chevron-right"></i></a>
                        
                        </div>
                        <!--END POST-CONTENT -->
                     </div>
                    </div>
                    <!--END POST-->
                    
                    <?php endwhile; ?>
                    
           <?php else : ?>
        
                <h2 class="center"><?php _e('Not Found', 'metromobile');?></h2>
                <p class="center"><?php _e('Sorry, but you are looking for something that isnt here.', 'metromobile');?></p>
                <?php get_search_form(); ?>
        
            <?php endif; ?>
   


            <!--END BLOG POSTS-->
            <!--START PAGENAVI-->	
            <div class="pagenavi">
            <?php
            $big = 999999999; 
            
            echo paginate_links( array(
            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format' => '?paged=%#%',
            'current' => max( 1, get_query_var('paged') ),
            'total' => $my_query->max_num_pages
            ) );
            ?>
            </div>		
            <!--END PAGENAVI-->
            </div>
            

            
            
<?php
	} 
?>