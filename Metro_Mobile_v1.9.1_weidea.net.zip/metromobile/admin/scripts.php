<?php

//Scripts
function load_theme_scripts() { 		
	 if (!is_admin()) {
		// add all the styles starts 
		
		wp_register_style('bootstrapdark',  get_template_directory_uri() . '/css/bootstrap-dark.css', false, '1.0', 'all');
		wp_register_style('bootstrapwhite',  get_template_directory_uri() . '/css/bootstrap-white.css', false, '1.0', 'all');
		wp_register_style('styles',  get_template_directory_uri() . '/style.css', false, '1.0', 'all');
		wp_register_style('camera',  get_template_directory_uri() . '/css/camera.css', false, '1.0', 'all');
		wp_register_style('tiles',  get_template_directory_uri() . '/css/tiles.css', false, '1.0', 'all');
		wp_register_style('add2home',  get_template_directory_uri() . '/css/add2home.css', false, '1.0', 'all');
		wp_register_style('fontawesome',  get_template_directory_uri() . '/css/font-awesome.css', false, '1.0', 'all');
		
		wp_register_script('spinner',  get_template_directory_uri() . '/js/spinner.js', array('jquery'), '1.0', false ); 
		wp_register_script('jqmobile',  get_template_directory_uri() . '/js/jquery.mobile.customized.min.js', array('jquery'), '1.0', false );  
		wp_register_script('camera',  get_template_directory_uri() . '/js/camera.js', array('jquery'), '1.0', false );  
		wp_register_script('easing',  get_template_directory_uri() . '/js/jquery.easing.1.3.js', array('jquery'), '1.0', false );
		wp_register_script('bootstrap',  get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '1.0', false );  
		wp_register_script('add2home',  get_template_directory_uri() . '/js/add2home.js', array('jquery'), '1.0', false ); 
		wp_register_script('modernzr',  get_template_directory_uri() . '/js/vendor/modernizr-2.6.1.min.js', array('jquery'), '2.6', false ); 
		wp_register_script('zepto',  get_template_directory_uri() . '/js/vendor/zepto.min.js', array('jquery'), '1.0', true ); 
		wp_register_script('custom',  get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0', true ); 
		wp_register_script('loadanim',  get_template_directory_uri() . '/js/loadanim.js', array(), '1.0', true ); 
		
		//De register nextgen gallery style
		wp_dequeue_style('NextGEN');
		wp_deregister_style( 'NextGEN' );
		wp_register_style( 'NextGEN', get_template_directory_uri() . '/css/nggallery.css', false, '1.0', 'all');
	}
}  

add_action('init', 'load_theme_scripts');
?>