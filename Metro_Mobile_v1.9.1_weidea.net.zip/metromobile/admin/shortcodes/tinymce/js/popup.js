
// start the popup specefic scripts
// safe to use $
jQuery(document).ready(function($) {
	
	
    var zillas = {
    	loadVals: function()
    	{
    		var shortcode = $('#_webbu_shortcode').text(),
    			uShortcode = shortcode;
    		
    		// fill in the gaps eg {{param}}
    		$('.webbu-input').each(function() {
    			var input = $(this),
    				id = input.attr('id'),
    				id = id.replace('webbu_', ''),		// gets rid of the webbu_ prefix
    				re = new RegExp("{{"+id+"}}","g");
    				
    			uShortcode = uShortcode.replace(re, input.val());
    		});
    		
    		// adds the filled-in shortcode as hidden input
    		$('#_webbu_ushortcode').remove();
    		$('#webbu-sc-form-table').prepend('<div id="_webbu_ushortcode" class="hidden">' + uShortcode + '</div>');
    	},
    	cLoadVals: function()
    	{
    		var shortcode = $('#_webbu_cshortcode').text(),
    			pShortcode = '';
    			shortcodes = '';
    		
    		// fill in the gaps eg {{param}}
    		$('.child-clone-row').each(function() {
    			var row = $(this),
    				rShortcode = shortcode;
    			
    			$('.webbu-cinput', this).each(function() {
    				var input = $(this),
    					id = input.attr('id'),
    					id = id.replace('webbu_', '')		// gets rid of the webbu_ prefix
    					re = new RegExp("{{"+id+"}}","g");
    					
    				rShortcode = rShortcode.replace(re, input.val());
    			});
    	
    			shortcodes = shortcodes + rShortcode + "\n";
    		});
    		
    		// adds the filled-in shortcode as hidden input
    		$('#_webbu_cshortcodes').remove();
    		$('.child-clone-rows').prepend('<div id="_webbu_cshortcodes" class="hidden">' + shortcodes + '</div>');
    		
    		// add to parent shortcode
    		this.loadVals();
    		pShortcode = $('#_webbu_ushortcode').text().replace('{{child_shortcode}}', shortcodes);
    		
    		// add updated parent shortcode
    		$('#_webbu_ushortcode').remove();
    		$('#webbu-sc-form-table').prepend('<div id="_webbu_ushortcode" class="hidden">' + pShortcode + '</div>');
    	},
    	children: function()
    	{
    		// assign the cloning plugin
    		$('.child-clone-rows').appendo({
    			subSelect: '> div.child-clone-row:last-child',
    			allowDelete: false,
    			focusFirst: false
    		});
    		
    		// remove button
    		$('.child-clone-row-remove').live('click', function() {
    			var	btn = $(this),
    				row = btn.parent();
    			
    			if( $('.child-clone-row').size() > 1 )
    			{
    				row.remove();
    			}
    			else
    			{
    				alert('You need a minimum of one row');
    			}
    			
    			return false;
    		});
    		
    		// assign jUI sortable
    		$( ".child-clone-rows" ).sortable({
				placeholder: "sortable-placeholder",
				items: '.child-clone-row'
				
			});
    	},
    	resizeTB: function()
    	{
			var	ajaxCont = $('#TB_ajaxContent'),
				tbWindow = $('#TB_window'),
				zillaPopup = $('#webbu-popup');

            
				if(zillaPopup.outerHeight() > 500){
					
					tbWindow.css({
					height: 500,
					width: zillaPopup.outerWidth(),
					marginLeft: -(zillaPopup.outerWidth()/2)
					});	
					
					}else{
						tbWindow.css({
						height: zillaPopup.outerHeight() +50,
						width: zillaPopup.outerWidth(),
						marginLeft: -(zillaPopup.outerWidth()/2)
						});	
						
						}
		

			ajaxCont.css({
				paddingTop: 0,
				paddingLeft: 0,
				paddingRight: 0,
				height: (tbWindow.outerHeight()-47),
				overflow: 'auto', // IMPORTANT
				width: zillaPopup.outerWidth()
			});
			
			$('#webbu-popup').addClass('no_preview');
    	},
    	load: function()
    	{
    		var	zillas = this,
    			popup = $('#webbu-popup'),
    			form = $('#webbu-sc-form', popup),
    			shortcode = $('#_webbu_shortcode', form).text(),
    			popupType = $('#_webbu_popup', form).text(),
    			uShortcode = '';
    		
    		// resize TB
    		zillas.resizeTB();
    		$(window).resize(function() { zillas.resizeTB() });
    		
    		// initialise
    		zillas.loadVals();
    		zillas.children();
    		zillas.cLoadVals();
    		
    		// update on children value change
    		$('.webbu-cinput', form).live('change', function() {
    			zillas.cLoadVals();
    		});
    		
    		// update on value change
    		$('.webbu-input', form).change(function() {
    			zillas.loadVals();
    		});
    		
    		// when insert is clicked
    		$('.webbu-insert', form).click(function() {    		 			
    			if(window.tinyMCE)
				{
					window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, $('#_webbu_ushortcode', form).html());
					tb_remove();
				}
    		});
    	}
	}
	    // run
    $('#webbu-popup').livequery( function() { zillas.load(); } );
});



	
