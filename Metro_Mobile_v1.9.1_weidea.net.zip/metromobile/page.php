<?php get_header(); ?>
<?php
$page = get_page_by_title($post->post_title);
if(isset($page) <> NULL){
$page_ID = $page->ID;
}else{
$page_ID = "";
}
$options = get_option('metromobile_options');

if ($page_ID == trim($options['portfolio_page_select'])) {
	$custom_page_selector = "portfolio";
} elseif ($page_ID == trim($options['blog_page_select'])) {
	 $custom_page_selector = "blog";
} else {
	 $custom_page_selector = "nothingspecial";
}	
	
if($custom_page_selector == "nothingspecial"){
?>
	<?php if (have_posts()){ ?>
    
        <?php while (have_posts()) : the_post(); ?>
        	
              <div class="wrapper">        
                <div class="scrollable">
					<header>
                            <h1><?php the_title(); ?></h1>
                            <a href="<?php echo dirname($_SERVER['PHP_SELF']);?>" class="back-button linkbut"></a>
                            <div class="line"></div>
                    </header>
                    <div class="MiddleContent"> 
                        	<?php the_content(); ?>
                    </div>
                </div>
             </div>
                
        <?php endwhile; ?>
        
    <?php } else { ?>
    
    	<p><?php _e('Sorry, no posts matched your criteria.', 'metromobile'); ?></p>
    
    <?php } ?>
    
<?php }else{ ?>
        	
    		<div class="wrapper">       
                <div class="scrollable">
					<header>
                            <h1 style="margin-left:90px; padding-top:3px;"><?php the_title(); ?></h1>
                            <a href="javascript:history.back(-1)" class="back-button linkbut"></a>
                            <a href="<?php echo home_url(); ?>" class="home-button linkbuthome"></a>
                            <div class="line"></div>
                    </header>
             
                    <div class="MiddleContent">
                        	<?php custom_page_sell($custom_page_selector); ?>
                    </div>
                </div>
             </div>
       
                
<?php } ?>  
   
<?php get_footer(); ?>