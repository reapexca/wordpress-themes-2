<?php
include 'admin/nhp-options.php';
include 'admin/scripts.php';
include 'admin/shortcodes/webbu-shortcodes.php';
include 'admin/pages.php';
include 'admin/pagination.php';
include 'admin/portfolio-gallery.php';

$options = get_option('metromobile_options');

// Auto Update
require_once("admin/class-pixelentity-theme-update.php");

if(isset($options['envatousername']) == NULL){$envatousername = "";}else{$envatousername = $options['envatousername'];}
if(isset($options['envatoapikey']) == NULL){$envatoapikey = "";}else{$envatoapikey = $options['envatoapikey'];}

$username = $envatousername;
$apikey = $envatoapikey;
$author = "Webbu";

//Custom page selector
function custom_page_sell($deger){
if($deger == "portfolio"){
	echo get_portfolio_page();
	}
elseif($deger == "blog"){
	echo get_blog_page();
	}
}
// Remove Admin bar
function remove_admin_bar()
{
    return false;
}
 
add_filter('show_admin_bar', 'remove_admin_bar'); // Remove Admin bar

//Navigation Menu Defaults
register_nav_menu( 'mainmenu', 'Main Mobile Menu' );

if ( ! isset( $content_width ) ) $content_width = 1024;

/* Localization */
function custom_theme_setup() {    
	load_theme_textdomain( 'metromobile', get_template_directory() . '/lang' );
}
add_action('after_setup_theme', 'custom_theme_setup');


//Sidebars
register_sidebar(array(
  'name' => 'Right Hand Sidebar',
  'id' => 'right-sidebar',
  'description' => 'Widgets in this area will be shown on the right-hand side.',
  'before_title' => '<h1>',
  'after_title' => '</h1>'
));
function pageselector($deger){
	$options = get_option('metromobile_options');

	if ($deger == trim($options['portfolio_page_select'])) {
		$output = "portfolio";
	} elseif ($deger == trim($options['blog_page_select'])) {
		 $output = "blog";
	} else {
		 $output = "nothingspecial";
	}	
	return $output;
}

?>