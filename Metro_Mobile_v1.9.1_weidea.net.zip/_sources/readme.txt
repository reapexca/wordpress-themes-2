Hi thank you purchase our template, :)

For use icons in to the PSD:
Font Awesome download address: http://fortawesome.github.com/Font-Awesome/
Roboto Font Download Address: http://www.fontsquirrel.com/fonts/roboto

 - First; Copy fontawesome font to your font directory of winodws of mac.

 - Second; You can find fontawesome icons : http://dl.dropbox.com/u/934214/pastable.html
   Just need to copy icons and paste into the PSD > Ico Text

I put some tile examples in to the tile-types.psd

You can find more Metro Icons in to the Sources folder. (http://metro.windowswiki.info/mi/)

Extra added splash screens and mobile app icons.

Thanks. And please don't forget to rate.