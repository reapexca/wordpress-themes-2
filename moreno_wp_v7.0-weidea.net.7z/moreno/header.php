<?php global $gittly_radius, $gittly_shadow; ?>
<!DOCTYPE HTML>
<html <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="bignet">
<meta charset="utf-8">
<title>
	<?php
	global $page, $paged;
	wp_title( '|', true, 'right' );
	bloginfo( 'name' );
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', 'gittly' ), max( $paged, $page ) );
	?>
</title>
<link rel="shortcut icon" href="<?php echo ot_get_option('favicon'); ?>">
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
    
<!--[if gte IE 9]>
	<style type="text/css">
		.gradient {
			filter: none;
         }
	</style>
<![endif]-->
<?php wp_head(); ?>
		
		
		
</head>

<body <?php body_class(); ?>>
<div id="wrapper">
	<div id="wrapper_inner">