<?php 
global $gittly_radius, $gittly_shadow;
if(is_page_template('template-home.php')): ?>
            <div class="front_menu">
            	 <?php if(has_nav_menu('main_menu')){
					wp_nav_menu( array('container'=>false, 'menu_id'=>'nav', 'theme_location'=>'main_menu') );
				 } ?>
            </div>
		<?php endif; ?>
        
    	<div class="<?php if(is_page_template('template-home.php')){ echo 'logo-warper'; } ?>">
            <div class="logo_area <?php if(is_page_template('template-home.php')){ echo 'front_page'; } ?>">
                <div class="gap"></div>
                <?php theme_logo(ot_get_option('logo'), ot_get_option('show_description'), ot_get_option('logo2x')); ?>
            </div><!--.logo_area-->
        </div>
        
        <div class="header_area <?php if(!is_page_template('template-home.php')){ echo $gittly_radius.' '.$gittly_shadow.' con_style'; } ?>">
        	<div class="clear" style="height:1px"></div>
            
            <?php if(!is_page_template('template-home.php')): ?>
            <div class="main_menu">
            	 <?php if(has_nav_menu('main_menu')){
					wp_nav_menu( array('container'=>false, 'menu_id'=>'nav', 'theme_location'=>'main_menu') );
				 } ?>
            </div>
            <?php endif; ?>
            
            <div class="clear" style="height:1px"></div>
            
            <?php if(!is_page_template('template-home.php')): ?>
            <div class="page_title">
				<?php if(is_home()): ?><h1><?php echo ot_get_option('blog_title'); ?></h1><span><?php echo ot_get_option('blog_subtitle'); ?></span><?php else: ?><h1><?php gittly_title() ?></h1><span><?php echo get_post_meta(get_the_ID(), 'wpage_subtitle', true) ?></span><?php endif; ?>
                 <div class="dea"></div>
                 <div class="clear"<?php if($gittly_shadow){ echo 'style="height:26px;"'; } ?>></div>
            </div>
            <?php endif; ?>
            
        </div><!--.header_area-->