<?php
/*-------------------------------------------
***Columns***
-------------------------------------------*/
function big_m_gallery($atts, $content = null, $code) {
	extract( shortcode_atts( array(
		'id' => '',
	), $atts ) );
	
	ob_start();
		$popup_child_class = 'image-magnificPopup';
		if(get_post_meta($id, 'gallery_slideshow', true) == 'yes'){ $popup_child_class = 'magnificPopup-child'; }
				
		$args = array(
			'post_type' => 'attachment',
			'numberposts' => -1,
			'post_status' => null,
			'post_parent' => $id
		);
						
		$gallery_images = get_post_meta($id, 'gallery_images', true);
		if ( $gallery_images ) {
			echo '<div class="group-image-magnificPopup single-gallery-images">';
				foreach ( $gallery_images as $gallery_image ) {
					$image_url = $gallery_image['image'];
					$image_id = get_attachment_id_by_src ($image_url);			
					$image_thumb = wp_get_attachment_image_src($image_id, 'gallery_thumb');
					$image_full = wp_get_attachment_image_src($image_id, 'full');
								
					if($gallery_image['link']){
						echo '<a href="'.$gallery_image['link'].'" class="g_img" title="'.$gallery_image['title'].'"><img src="' . $image_thumb[0] . '"/></a>';
					}else{
						echo '<a href="'.$image_full[0].'" class="g_img '.$popup_child_class.'" title="'.$gallery_image['title'].'"><img src="' . $image_thumb[0] . '"/></a>';
					}
				}
			echo '</div>';				
		}
	$output = ob_get_contents();
	ob_end_clean();
	
	return 	$output;
}
add_shortcode('m_gallery', 'big_m_gallery');