<?php
include('../../../../../../wp-load.php');
?>
<script type="text/javascript">
var GalleryDialog = {
	local_ed : 'ed',
	init : function(ed) {
		GalleryDialog.local_ed = ed;
		tinyMCEPopup.resizeToInnerSize();
	},
	insert : function insertgallery(ed) {
	 
		// Try and remove existing style / blockquote
		tinyMCEPopup.execCommand('mceRemoveNode', false, null);
		 
		// set up variables to contain our input values
		var gallery_id = jQuery('select#gallery-id').val();
		
		if(gallery_id){ gallery_id = 'id="'+gallery_id+'" ' }
		
		//set highlighted content variable
		var mceSelected = tinyMCE.activeEditor.selection.getContent();
		 
		var output = '';
		
		// setup the output of our shortcode
		output = '[m_gallery '+gallery_id+' /]';
		
		tinyMCEPopup.execCommand('mceReplaceContent', false, output);
		 
		// Return
		tinyMCEPopup.close();
	}
};
tinyMCEPopup.onInit.add(GalleryDialog.init, GalleryDialog);
 
</script>
<form action="/" method="get" accept-charset="utf-8">
    <div class="form-section galleryfix">
        <label for="gallery-text">ID</label>       
        <select id="gallery-id" name="gallery-id">
        	<?php $gallery_query = new WP_Query( array( 'post_type' => 'wpz_gallery', 'posts_per_page'=> -1 ) ); ?>
            <?php while ( $gallery_query->have_posts() ) : $gallery_query->the_post(); ?>
            	<option value="<?php the_ID(); ?>"><?php the_title(); ?></option>
            <?php endwhile; ?>
            <?php wp_reset_postdata(); ?>
        </select>
    </div>
	<a href="javascript:GalleryDialog.insert(GalleryDialog.local_ed)" id="insert" style="display: block; line-height: 24px;">Insert</a>
</form>