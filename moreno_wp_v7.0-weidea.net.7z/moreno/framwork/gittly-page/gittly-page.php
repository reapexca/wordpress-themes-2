<?php
/*
Plugin Name: Gittly Page
Plugin URI: #
Description: page Plugin.
Version: 1.0.1
Author: Sazzad H
Author URI: #
License: GPL2+
*/

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

// windows-proof constants: replace backward by forward slashes - thanks to: https://github.com/peterbouwmeester
$fslashed_dir = trailingslashit(str_replace('\\','/',dirname(__FILE__)));
$fslashed_abs = trailingslashit(str_replace('\\','/',ABSPATH));

if ( ! defined( 'GITTLY_PAGE_URL' ) ) define( 'GITTLY_PAGE_URL', site_url(str_replace( $fslashed_abs, '', $fslashed_dir )) );
if ( ! defined( 'GITTLY_PAGE_DIR' ) ) define( 'GITTLY_PAGE_DIR', $fslashed_dir );






/*Register Meta Box
--------------------------------------------------------------------------*/

$metabox = array();
$metabox[] = array(
        'id'          => 'tplhome_box_style',
        'label'       => __('Blox Style', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array( 
		  array( 'value' => 'circle', 'label' => 'circle', 'src' => '' ),
		  array( 'value' => 'square', 'label' => 'square', 'src' => '' ),
		  array( 'value' => 'rounded', 'label' => 'rounded', 'src' => '' ),
		  array( 'value' => 'hexagon', 'label' => 'hexagon', 'src' => '' ),
		  array( 'value' => 'egg', 'label' => 'egg', 'src' => '' ),
		  array( 'value' => 'image-only', 'label' => 'image-only', 'src' => '' ),
        ),
      );
	$metabox[] = array(
        'id'          => 'tplhome_image',
        'label'       => __('Main Image', 'gittly'),
        'desc'        => __('Upload an image, specify an image URL, or leave blank to use title and sub-title.', 'gittly'),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
    );
	$metabox[] = array(
        'id'          => 'tplhome_image2x',
        'label'       => __('Main Image (Retina Image)', 'gittly'),
        'desc'        => __('Upload the 2x size of the image image', 'gittly'),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
    );
	$metabox[] = array(
        'id'          => 'tplhome_image_size',
        'label'       => __('Image Size', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array( 
		  array( 'value' => '100', 'label' => '100%', 'src' => '' ),
		  array( 'value' => '75', 'label' => '75%', 'src' => '' ),
		  array( 'value' => '50', 'label' => '50%', 'src' => '' ),
		  array( 'value' => '25', 'label' => '25%', 'src' => '' ),
        ),
      );  
	   $metabox[] = array(
        'id'          => 'tplhome_title',
        'label'       => __('Title', 'gittly'),
        'desc'        => __('If you do not want to display text title please input <code>n/a</code>', 'gittly'),
        'std'         => 'Moreno',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	   $metabox[] = array(
        'id'          => 'tplhome_subtitle',
        'label'       => __('Sub-Title', 'gittly'),
        'desc'        => __('If you do not want to display text sub-title please input <code>n/a</code>', 'gittly'),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	  $metabox[] = array(
        'id'          => 'tplhome_subtitle_divider',
        'label'       => __('Display Sub-Title Divider', 'gittly'),
        'desc'        => '',
        'std'         => 'yes',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array( 
		  array( 'value' => 'yes', 'label' => 'Yes', 'src' => '' ),
		  array( 'value' => 'no', 'label' => 'No', 'src' => '' ),
        ),
      );
	  
	  $metabox[] = array(
        'id'          => 'tplhome_top_margin',
        'label'       => __('Top Margin  of the Image', 'gittly'),
        'desc'        => __('PX', 'gittly'),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	
	  $metabox[] = array(
        'id'          => 'tplhome_image_link',
        'label'       => __('Link of the Image', 'gittly'),
        'desc'        => __('include the full URL <code>http://</code>', 'gittly'),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	   $metabox[] = array(
        'id'          => 'tplhome_text_color',
        'label'       => __('Text Color', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  $metabox[] = array(
        'id'          => 'tplhome_bg_color',
        'label'       => __('Background Color', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  $metabox[] = array(
        'id'          => 'tplhome_bg_opacity',
        'label'       => __('Background Opacity', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array( 
		  array( 'value' => '1', 'label' => '1', 'src' => '' ),
		  array( 'value' => '0.9', 'label' => '0.9', 'src' => '' ),
		  array( 'value' => '0.8', 'label' => '0.8', 'src' => '' ),
		  array( 'value' => '0.7', 'label' => '0.7', 'src' => '' ),
		  array( 'value' => '0.6', 'label' => '0.6', 'src' => '' ),
		  array( 'value' => '0.5', 'label' => '0.5', 'src' => '' ),
		  array( 'value' => '0.4', 'label' => '0.4', 'src' => '' ),
		  array( 'value' => '0.3', 'label' => '0.3', 'src' => '' ),
		  array( 'value' => '0.2', 'label' => '0.2', 'src' => '' ),
          array( 'value' => '0.1', 'label' => '0.1', 'src' => '' ),
		  array( 'value' => '0.0', 'label' => '0.0', 'src' => '' ),  
        ),
      );
	  
new gittly_option_tree_metabox(array('page'), __('Home Page Setting', 'gittly'), 'home_page_setting', $metabox);

$metabox = array(
	array(
        'id'          => 'enable_people_1',
        'label'       => __('Enable 1st Profile', 'gittly'),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on_off',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	array(
        'id'          => 'people_image_1',
        'label'       => __('People Image', 'gittly'),
        'desc'        => '',
        'std'         => 'http://placehold.it/299x299',
        'type'        => 'upload',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_1:is(on)',
		'operator'    => 'or'
      ),
	   array(
        'id'          => 'people_link_1',
        'label'       => __('Link', 'gittly'),
        'desc'        => __('include the full URL including http://', 'gittly'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_1:is(on)',
		'operator'    => 'or'
      ),
	  array(
        'id'          => 'people_name_1',
        'label'       => __('Person Name', 'gittly'),
        'desc'        => __('', 'gittly'),
        'std'         => 'Mary Anna',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_1:is(on)',
		'operator'    => 'or'
      ),
	  array(
        'id'          => 'people_position_1',
        'label'       => __('Person Position', 'gittly'),
        'desc'        => __('', 'gittly'),
        'std'         => 'Photographer',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_1:is(on)',
		'operator'    => 'or'
	),
	array(
        'id'          => 'social_icon_1',
        'label'       => __('Social Icons', 'gittly'),
        'desc'        => __('', 'gittly'),
        'std'         => array(
							array('title'=> 'Facebook', 'link'=> '#', 'icon'=> 'fa-facebook'),
							array('title'=> 'Twitter', 'link'=> '#', 'icon'=> 'fa-twitter'),
							array('title'=> 'Vimeo', 'link'=> '#', 'icon'=> 'fa-vimeo-square'),
							array('title'=> 'Dribbble', 'link'=> '#', 'icon'=>'fa-dribbble'),
						),
        'type'        => 'list-item',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_1:is(on)',
		'operator'    => 'or',
		'settings'    => array(
			array(
				'id'          => 'link',
				'label'       => __('Link', 'digita_taxdomain'),
				'desc'        => '',
				'std'         => '',
				'type'        => 'text',
				'section'     => '',
				'rows'        => '',
				'post_type'   => '',
				'taxonomy'    => '',
				'class'       => '',
				'choices'     => '',
			),
			array(
				'id'          => 'icon',
				'label'       => __('Select a Icon', 'gittly'),
				'desc'        => '',
				'std'         => '',
				'type'        => 'select',
				'section'     => '',
				'rows'        => '',
				'post_type'   => '',
				'taxonomy'    => '',
				'class'       => '',
				'choices'     => array( 
					array('value' => 'fa-dribbble', 'label' => 'Dribbble'),
					array('value' => 'fa-pinterest', 'label' => 'Pinterest'),
					array('value' => 'fa-stack-overflow', 'label' => 'Stack Overflow'),
					array('value' => 'fa-twitter', 'label' => 'Twitter'),
					array('value' => 'fa-dropbox', 'label' => 'dropbox'),
					array('value' => 'fa-instagram', 'label' => 'instagram'),
					array('value' => 'fa-renren', 'label' => 'renren'),
					array('value' => 'fa-youtube-play', 'label' => 'youtube'),
					array('value' => 'fa-facebook', 'label' => 'facebook'),
					array('value' => 'fa-google-plus', 'label' => 'google-plus'),
					array('value' => 'fa-skype', 'label' => 'skype'),
					array('value' => 'fa-tumblr', 'label' => 'tumblr'),
					array('value' => 'fa-vimeo-square', 'label' => 'vimeo'),
					array('value' => 'fa-bitbucket', 'label' => 'bitbucket'),
					array('value' => 'fa-github-alt', 'label' => 'github'),
					array('value' => 'fa-linkedin', 'label' => 'linkedin'),
					array('value' => 'fa-pinterest', 'label' => 'pinterest'),
					array('value' => 'fa-stack-exchange', 'label' => 'stack-exchange'),
				),
			),
		),
	),
	array(
        'id'          => 'text_block_111',
        'label'       => __('', 'gittly'),
        'desc'        => __('<hr><hr><hr><hr><hr>', 'gittly'),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
	),
	array(
        'id'          => 'enable_people_2',
        'label'       => __('Enable 2nd Profile', 'gittly'),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on_off',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	array(
        'id'          => 'people_image_2',
        'label'       => __('People Image', 'gittly'),
        'desc'        => '',
        'std'         => 'http://placehold.it/299x299',
        'type'        => 'upload',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_2:is(on)',
		'operator'    => 'or',
      ),
	  array(
        'id'          => 'people_link_2',
        'label'       => __('Link', 'gittly'),
        'desc'        => __('include the full URL including http://', 'gittly'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_2:is(on)',
		'operator'    => 'or',
      ),
	  array(
        'id'          => 'people_name_2',
        'label'       => __('Person Name', 'gittly'),
        'desc'        => __('', 'gittly'),
        'std'         => 'Jay Poco',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_2:is(on)',
		'operator'    => 'or',
      ),
	  array(
        'id'          => 'people_position_2',
        'label'       => __('Person Position', 'gittly'),
        'desc'        => __('', 'gittly'),
        'std'         => 'Developer',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_2:is(on)',
		'operator'    => 'or',
	),
	array(
        'id'          => 'social_icon_2',
        'label'       => __('Social Icons', 'gittly'),
        'desc'        => __('', 'gittly'),
        'std'         => array(
							array('title'=> 'Facebook', 'link'=> '#', 'icon'=> 'fa-facebook'),
							array('title'=> 'Twitter', 'link'=> '#', 'icon'=> 'fa-twitter'),
							array('title'=> 'Vimeo', 'link'=> '#', 'icon'=> 'fa-vimeo-square'),
							array('title'=> 'Dribbble', 'link'=> '#', 'icon'=>'fa-dribbble'),
						),
        'type'        => 'list-item',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
		'condition'   => 'enable_people_2:is(on)',
		'operator'    => 'or',
		'settings'    => array(
			array(
				'id'          => 'link',
				'label'       => __('Link', 'digita_taxdomain'),
				'desc'        => '',
				'std'         => '',
				'type'        => 'text',
				'section'     => '',
				'rows'        => '',
				'post_type'   => '',
				'taxonomy'    => '',
				'class'       => '',
				'choices'     => '',
			),
			array(
				'id'          => 'icon',
				'label'       => __('Select a Icon', 'gittly'),
				'desc'        => '',
				'std'         => '',
				'type'        => 'select',
				'section'     => '',
				'rows'        => '',
				'post_type'   => '',
				'taxonomy'    => '',
				'class'       => '',
				'choices'     => array( 
					array('value' => 'fa-dribbble', 'label' => 'Dribbble'),
					array('value' => 'fa-pinterest', 'label' => 'Pinterest'),
					array('value' => 'fa-stack-overflow', 'label' => 'Stack Overflow'),
					array('value' => 'fa-twitter', 'label' => 'Twitter'),
					array('value' => 'fa-dropbox', 'label' => 'dropbox'),
					array('value' => 'fa-instagram', 'label' => 'instagram'),
					array('value' => 'fa-renren', 'label' => 'renren'),
					array('value' => 'fa-youtube-play', 'label' => 'youtube'),
					array('value' => 'fa-facebook', 'label' => 'facebook'),
					array('value' => 'fa-google-plus', 'label' => 'google-plus'),
					array('value' => 'fa-skype', 'label' => 'skype'),
					array('value' => 'fa-tumblr', 'label' => 'tumblr'),
					array('value' => 'fa-vimeo-square', 'label' => 'vimeo'),
					array('value' => 'fa-bitbucket', 'label' => 'bitbucket'),
					array('value' => 'fa-github-alt', 'label' => 'github'),
					array('value' => 'fa-linkedin', 'label' => 'linkedin'),
					array('value' => 'fa-pinterest', 'label' => 'pinterest'),
					array('value' => 'fa-stack-exchange', 'label' => 'stack-exchange'),
				),
			),
		),
	),
);
new gittly_option_tree_metabox(array('page', 'wpz_gallery'), __('About Page Setting', 'gittly'), 'about_page_setting', $metabox);


$metabox = array(
	array(
        'id'          => 'wpage_subtitle',
        'label'       => __('Sub Title', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
	  array(
        'id'          => 'wpage_enable_bg_slideshow',
        'label'       => __('Enable Background Image Slideshow', 'gittly'),
        'desc'        => __('This option will hemp you enable or disable background slideshow. Select "NO" if you want to display a background image or color.', 'gittly'),
        'std'         => 'yes',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array( 
		  array( 'value' => 'yes', 'label' => 'Yes', 'src' => '' ),
		  array( 'value' => 'no', 'label' => 'No', 'src' => '' ),
        ),
      ),
	  array(
        'id'          => 'wpage_images',
        'label'       => __('Balckground Slider Images', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'list-item',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'settings'    => array( 
          array(
            'id'          => 'image',
            'label'       => 'Image',
            'desc'        => '',
            'std'         => '',
            'type'        => 'upload',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'class'       => ''
          )
        )
	),
	array(
        'id'          => 'wpage_bg',
        'label'       => __('Balckground', 'gittly'),
        'desc'        => __('Balckground will only work if you disable background slideshow', 'gittly'),
        'std'         => '',
        'type'        => 'background',
        'section'     => 'portfolio_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'settings'    => ''
	),

);
new gittly_option_tree_metabox(array('page', 'post', 'wpz_gallery'), __('Page Setting', 'gittly'), 'page_setting', $metabox);