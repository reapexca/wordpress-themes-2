<?php
/**
 * Initialize the options before anything else.
 */
add_action( 'admin_init', 'gittly_theme_options', 1 );

/**
 * Build the custom settings & update OptionTree.
 */
function gittly_theme_options() {
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( 'option_tree_settings', array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
	
    'sections'        => array( 
     array( 'id' => 'general','title' => 'General'),
	 array( 'id' => 'styling','title' => 'Styling'),
	 array( 'id' => 'bgslideshow','title' => 'Background Slideshow'),
	 array( 'id' => 'blog_page','title' => 'Blog Page'),
	 array( 'id' => 'social','title' => 'Social Profiles'),
  	 array( 'id' => 'typography','title' => 'Typography'),
	 array( 'id' => 'integration','title' => 'Integration'),
	 array( 'id' => 'footer','title' => 'Footer'),
	 
	 ),

    'settings' => array()
  );
  
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('general-options.php'));
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('styling-options.php'));
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('bgslideshow-options.php'));
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('blog-options.php'));
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('social-options.php'));
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('integration-options.php'));
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('typography.php'));
  $custom_settings ['settings'] = array_merge($custom_settings['settings'], include('footer-options.php'));


  
  //print_r($custom_settings ['settings']);
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( 'option_tree_settings_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( 'option_tree_settings', $custom_settings ); 
  }
  
}


add_action('wp_head', 'option_header_code');
function option_header_code(){
	?>
    <style type="text/css">
		.logo_area .gap{ height:<?php echo ot_get_option('logo_top_margin_inner'); ?>px !important; }
		
		<?php
		if(ot_get_option('color_option_1')){ 
			echo 'a, a:visited,
			     .widget ul li a:hover,
				 #footer_widget .widget ul li a:hover,
				 .widget_archive ul li a:hover,
				 #footer_widget .widget_archive ul li a:hover,
				 .widget_calendar table#wp-calendar>tbody>tr>td>a,
				 .widget_calendar tfoot>tr>td>a, tfoot>tr>td>a:link, tfoot>tr>td>a:visited, tfoot>tr>td>a:hover, tfoot>tr>td>a:active,
				 .widget_categories ul li a:hover,
				 #footer_widget .widget_categories ul li a:hover,
				 .widget_links ul li a:hover,
				 #footer_widget .widget_links ul li a:hover,
				 .widget_recent_comments ul li:hover,
				 #footer_widget .widget_recent_comments ul li:hover,
				 .widget_recent_entries ul li a:hover,
				 #footer_widget .widget_recent_entries ul li a:hover,
				 .widget_rss ul li a:hover,
				 #footer_widget .widget_rss ul li a:hover,
				 #nav li a:hover,
				 #nav li ul li a:hover,
				 .footer-menu ul li a:hover,
				 .toggle .title:hover,
				 .toggle .title.active{ color:'.ot_get_option('color_option_1').'; }'; 
			
			echo 'blockquote,
			      .widget_search input[type="submit"],
				  #footer_widget .widget_search input[type="submit"],
				  #nav li ul,
				  .progress-bar-content,
				  .title_2 p{ border-color:'.ot_get_option('color_option_1').' ; }'; 
			
			echo '.widget_search input[type="submit"],
			      .tagcloud a:hover,
				  #footer_widget .tagcloud a:hover,
				  .widget_calendar thead>tr>th,
				  #footer_widget .widget_search input[type="submit"],
				  .progress-bar-content,
				  .button{ background-color:'.ot_get_option('color_option_1').'; }'; 
		}
		
		
		if(ot_get_option('color_option_2')){ 
			echo 'body,
			      #logo h1 a,
				  #nav li a,
				  #nav li a:hover,
				  .copyright,
				  .paginate a,
				  #prevslide,
				  #nextslide,
				  .blog_item .date,
				  .blog_item .date a,
				  .tags_area strong,
				  .home-box-warper h1 a{ color:'.ot_get_option('color_option_2').'; }'; 
			
			//echo 'sss{ border-color:'.ot_get_option('color_option_1').' ; }'; 
			
			echo '.wpcf7-form input[type="submit"],
			.dea{ background-color:'.ot_get_option('color_option_2').'; }'; 
		}
		
		
		
		if(ot_get_option('color_option_3')){ 
			echo '.widget ul li a,
			      .widget_archive ul li a,
				  .widget_categories ul li a,
				  .widget_links ul li a,
				  .widget_recent_comments ul li,
				  .widget_recent_entries ul li a,
				  .widget_rss ul li a{ color:'.ot_get_option('color_option_3').'; }'; 
		}
		
		
		if(ot_get_option('headings_color')){ 
			echo 'h1, h2, h3, h4, h5, h6,
			      .blog_item h2 a,{ color:'.ot_get_option('headings_color').'; }'; 
		}
		
		
		if(is_array(ot_get_option('page_background')) && ot_get_option('page_background')){
			
			$body_bg = ot_get_option('page_background');
			
			if($body_bg['background-attachment']){ echo 'body{ background-attachment:'.$body_bg['background-attachment'].'; }'; }
			if($body_bg['background-color']){ echo 'body{ background-color:'.$body_bg['background-color'].'; }'; }
			if($body_bg['background-image']){ echo 'body{ background-image:url('.$body_bg['background-image'].'); }'; }
			if($body_bg['background-position']){ echo 'body{ background-position:'.$body_bg['background-position'].'; }'; }
			if($body_bg['background-repeat']){ echo 'body{ background-repeat:'.$body_bg['background-repeat'].'; }'; }
		}
		
		?>
	</style>
    
    <?php if(ot_get_option('custom_css')): ?>
	<style type="text/css">
		<?php echo ot_get_option('custom_css'); ?>
	</style>
    <?php endif; ?>
    
    <?php if(ot_get_option('custom_js')): ?>
	<script type="text/javascript">
		<?php echo ot_get_option('custom_js'); ?>
	</script>
    <?php endif; ?>
    
    <?php if(ot_get_option('google_analytics')): ?>
		<?php echo ot_get_option('google_analytics'); ?>
    <?php endif; ?>
    
    <?php
}