<?php
$the_array = array();

	$the_array[] = array(
        'id'          => 'color_option_1',
        'label'       => __('Color Option One', 'gittly'),
        'desc'        => __('This is the color of links, menu border, buttons', 'gittly'),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'styling',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
	);
	
	$the_array[] = array(
        'id'          => 'color_option_2',
        'label'       => __('Color Option Two', 'gittly'),
        'desc'        => __('Color of Text, Logo title, site description, Post Meta', 'gittly'),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'styling',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
	);
	
	$the_array[] = array(
        'id'          => 'color_option_3',
        'label'       => __('Color Option Three', 'gittly'),
        'desc'        => __('Color of sidebar and Footer widget\'s List', 'gittly'),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'styling',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
	);
	
	$the_array[] = array(
        'id'          => 'headings_color',
        'label'       => __('Headings Color', 'gittly'),
        'desc'        => __('Color of H1, H2, H3, H4, H5, H6', 'gittly'),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'styling',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
	);
	
	
	$the_array[] = array(
        'id'          => 'page_background',
        'label'       => __('Page Background', 'gittly'),
        'desc'        => __('Background Color / Image of the site', 'gittly'),
        'std'         => '',
        'type'        => 'background',
        'section'     => 'styling',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
	);
return $the_array;	