<?php
$the_array = array();
	$the_array[] = array(
        'id'          => 'social_enable',
        'label'       => __('Enable Social Bar', 'gittly'),
        'desc'        => '',
        'std'         => 'yes',
        'type'        => 'select',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array( 
          array(
            'value'       => 'yes',
            'label'       => 'Yes',
            'src'         => ''
          ),
          array(
            'value'       => 'no',
            'label'       => 'No',
            'src'         => ''
          )
        ),
      );
		
		
	  /*$the_array[] = array(
        'id'          => 'social_twitter',
        'label'       => __('Twitter Profile URL', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	  $the_array[] = array(
        'id'          => 'social_dribbble',
        'label'       => __('Dribbble Profile URL', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	  $the_array[] = array(
        'id'          => 'social_facebook',
        'label'       => __('Facebook Profile URL', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	  $the_array[] = array(
        'id'          => 'social_vimeo',
        'label'       => __('Vimeo Profile URL', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  $the_array[] = array(
        'id'          => 'social_instagram',
        'label'       => __('Instagram URL', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  $the_array[] = array(
        'id'          => 'social_pinterest',
        'label'       => __('Pinterest URL', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );*/
	  
	 $social_icons_std =  array(
		array('title'=> 'Dribbble', 'link'=> '#', 'icon'=>'fa-dribbble'),
		array('title'=> 'Twitter', 'link'=> '#', 'icon'=> 'fa-twitter'),
		array('title'=> 'Facebook', 'link'=> '#', 'icon'=> 'fa-facebook'),
		array('title'=> 'Google Plus', 'link'=> '#', 'icon'=> 'fa-google-plus'),
		array('title'=> 'Pinterest', 'link'=> '#', 'icon'=> 'fa-pinterest'),
		array('title'=> 'Vimeo', 'link'=> '#', 'icon'=> 'fa-vimeo-square'),
		array('title'=> 'Instagram', 'link'=> '#', 'icon'=> 'fa-instagram'),
		array('title'=> 'Youtube', 'link'=> '#', 'icon'=> 'fa-youtube-play'),
	);
	
	 $the_array[] = array(
        'id'          => 'social_icons',
        'label'       => __('Social Profile Icons', 'gittly'),
        'desc'        => '',
        'std'         => $social_icons_std,
        'type'        => 'list-item',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'settings'    => array(
			array(
				'id'          => 'link',
				'label'       => __('Link', 'gittly'),
				'desc'        => '',
				'std'         => '',
				'type'        => 'text',
				'section'     => '',
				'rows'        => '',
				'post_type'   => '',
				'taxonomy'    => '',
				'class'       => '',
				'choices'     => '',
			),
			array(
				'id'          => 'icon',
				'label'       => __('Select a Icon', 'gittly'),
				'desc'        => '',
				'std'         => '',
				'type'        => 'select',
				'section'     => '',
				'rows'        => '',
				'post_type'   => '',
				'taxonomy'    => '',
				'class'       => '',
				'choices'     => array( 
					array('value' => 'fa-dribbble', 'label' => 'Dribbble'),
					array('value' => 'fa-pinterest', 'label' => 'Pinterest'),
					array('value' => 'fa-stack-overflow', 'label' => 'Stack Overflow'),
					array('value' => 'fa-twitter', 'label' => 'Twitter'),
					array('value' => 'fa-dropbox', 'label' => 'dropbox'),
					array('value' => 'fa-instagram', 'label' => 'instagram'),
					array('value' => 'fa-renren', 'label' => 'renren'),
					array('value' => 'fa-youtube-play', 'label' => 'youtube'),
					array('value' => 'fa-facebook', 'label' => 'facebook'),
					array('value' => 'fa-google-plus', 'label' => 'google-plus'),
					array('value' => 'fa-skype', 'label' => 'skype'),
					array('value' => 'fa-tumblr', 'label' => 'tumblr'),
					array('value' => 'fa-vimeo-square', 'label' => 'vimeo'),
					array('value' => 'fa-bitbucket', 'label' => 'bitbucket'),
					array('value' => 'fa-github-alt', 'label' => 'github'),
					array('value' => 'fa-linkedin', 'label' => 'linkedin'),
					array('value' => 'fa-pinterest', 'label' => 'pinterest'),
					array('value' => 'fa-stack-exchange', 'label' => 'stack-exchange'),
				),
			),
			
		),
	);
return $the_array;	