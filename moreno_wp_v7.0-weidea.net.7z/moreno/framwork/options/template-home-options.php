<?php
$the_array = array();
	
	$the_array[] = array(
        'id'          => 'main_image',
        'label'       => __('Home Logo Image', 'gittly'),
        'desc'        => __('Upload an image, specify an image URL, or leave blank to use title and sub-title.', 'gittly'),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	   $the_array[] = array(
        'id'          => 'tplhome_logo_title',
        'label'       => __('Title', 'gittly'),
        'desc'        => __('If you do not want to display text title please leave it blank', 'gittly'),
        'std'         => 'Moreno',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	   $the_array[] = array(
        'id'          => 'tplhome_logo_subtitle',
        'label'       => __('Sub-Title', 'gittly'),
        'desc'        => __('If you do not want to display text sub-title please leave it blank', 'gittly'),
        'std'         => 'JUST ANOTHER WORDPRESS SITE',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  
	  $the_array[] = array(
        'id'          => 'tplhome_logo_top_margin',
        'label'       => __('Margin top of the Logo', 'gittly'),
        'desc'        => __('PX', 'gittly'),
        'std'         => '170',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	
	  $the_array[] = array(
        'id'          => 'tplhome_logo_link',
        'label'       => __('Link of the logo', 'gittly'),
        'desc'        => __('include the full URL <code>http://</code>', 'gittly'),
        'std'         => '#',
        'type'        => 'text',
        'section'     => 'template_home',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
		
return $the_array;	