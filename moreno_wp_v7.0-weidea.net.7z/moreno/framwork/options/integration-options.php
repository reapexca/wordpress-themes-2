<?php
$the_array = array();
	$the_array[] = array(
        'id'          => 'custom_css',
        'label'       => __('Custom CSS', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'integration',
        'rows'        => '5',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  $the_array[] = array(
        'id'          => 'custom_js',
        'label'       => __('Custom JavaScript', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'integration',
        'rows'        => '5',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
	  $the_array[] = array(
        'id'          => 'google_analytics',
        'label'       => __('Google Analytics', 'gittly'),
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'integration',
        'rows'        => '5',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      );
return $the_array;	