		<?php if(ot_get_option('enable_footer')=='yes'): ?>
        	<?php if(is_page_template('template-home.php') == false): ?>
                <div class="content_area con_style shadow radius margin_top"><div class="clear"></div>
                    <div class="content_inner" style="width:90%; margin-bottom:20px;">
                        <div class="clear" style="height:25px;"></div>
                        <div class="container">
                            <div class="col col_1_3"><?php dynamic_sidebar('footer_widgets_1'); ?></div>
                            <div class="col col_1_3"><?php dynamic_sidebar('footer_widgets_2'); ?></div>
                            <div class="col col_1_3"><?php dynamic_sidebar('footer_widgets_3'); ?></div>
                        </div>
                        <div class="clear"></div>
                    </div><!--#footer_widget_inner-->
                    <div class="clear"></div>
                </div><!--#footer_widget-->
        	<?php endif; ?>
		<?php endif; ?>
        
        <?php digita_wpml_language_switcher('<div class="digita_wpml_flags">', '</div>'); ?>
		
        <?php if(ot_get_option('social_enable')=='yes'): ?>
            <div class="social_bar">
                <?php
                if(is_array(ot_get_option('social_icons'))){
                    foreach(ot_get_option('social_icons') as $icon){
                        echo '<a href="'.$icon['link'].'" target="_blank" rel="nofollow" title="'.$icon['title'].'"><i class="fa '.$icon['icon'].'"></i></a>';	
                    }
                }
                ?>
            </div><!--.social_bar-->
        <?php endif; ?>
        
        <div class="copyright <?php if(is_page_template('template-home.php')){ echo 'front_page'; } ?>">
        	<?php echo ot_get_option('footer_copyright_text'); ?>
        </div><!--.copyright-->
        
	</div><!--#wrapper_inner-->
</div><!--#wrapper-->

<?php if(get_post_meta(get_the_ID(), 'wpage_enable_bg_slideshow', true) == 'no'): ?>
	
<?php else: ?>
    <!--Arrow Navigation-->
    <a id="prevslide" class="load-item <?php if(is_page_template('template-home.php')){ echo 'front_page'; }else{ echo 'inner_page';} ?>"><i class="fa fa-chevron-left"></i></a>
    <a id="nextslide" class="load-item <?php if(is_page_template('template-home.php')){ echo 'front_page'; }else{ echo 'inner_page';} ?>"><i class="fa fa-chevron-right"></i></a>
            
    <!--Time Bar-->
    <div id="progress-back" class="load-item">
        <div id="progress-bar"></div>
    </div>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>