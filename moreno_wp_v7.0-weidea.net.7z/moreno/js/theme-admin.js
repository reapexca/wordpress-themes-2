jQuery(document).ready(function($) {

	function show_hide_metabox(metabox_id, template_id){
		$(metabox_id).css({'display':'none'});
		
		if( $("#page_template").attr('checked', true).val() == template_id){
			$(metabox_id).css({'display':'block'});
		}
		
		$("#page_template").live('change',function(){
			
			var getCurrentTemplate = $("#page_template").val();
			
			if( getCurrentTemplate == template_id){
					
					$(metabox_id).css({'display':'block'});
			}else{
				$("#page_template").attr('checked', false);
				$(metabox_id).css({'display':'none'});
			}
			
		});
	}
	
	show_hide_metabox('#home_page_setting', 'template-home.php');
	show_hide_metabox('#about_page_setting', 'template-about.php');
	//show_hide_metabox('#digita_blog_metabox', 'pages/blog.php');
	
});