<?php
/*
Template Name: About Template
*/
$gittly_radius = 'radius_top'; $gittly_shadow = ''; ?>
<?php get_header(); ?>
<?php get_template_part('_header',''); ?>

<div class="content_area con_style shadow radius_buttom">
	<div class="clear"></div>
	<div class="content_inner">
		<?php 
			if( have_posts() ){
				while ( have_posts() ){ the_post(); ?> 
					<?php the_content(); ?>
                    <?php wp_link_pages(array('before' => '<p class="page_nav_link">' . __('Pages:', 'gittly'), 'after' => '</p>',)); ?>
				<?php }
			}
		?><div class="clear"></div>
        	<?php if(get_post_meta(get_the_ID(), 'enable_people_1', true) == 'on'): ?>
                <div class="people_itam">
                	<div class="people_image" style="background-image:url(<?php echo get_post_meta(get_the_ID(),'people_image_1', true); ?>);">
                    <?php if(get_post_meta(get_the_ID(),'people_link_1', true) != ''): ?><a href="<?php echo get_post_meta(get_the_ID(),'people_link_1', true); ?>"><?php endif; ?>
						<p>&nbsp;</p>
                    <?php if(get_post_meta(get_the_ID(),'people_link_1', true) != ''): ?></a><?php endif; ?>
                    </div>
                    <div class="people_info">
                    	<h1><?php echo get_post_meta(get_the_ID(),'people_name_1', true); ?></h1>
                		<span><?php echo get_post_meta(get_the_ID(),'people_position_1', true); ?></span>
                        <div class="dea"></div>
<?php if(is_array(get_post_meta(get_the_ID(),'social_icon_1', true))): ?>
	<?php foreach(get_post_meta(get_the_ID(),'social_icon_1', true) as $abouticonn): ?>
                        <a href="<?php echo $abouticonn['link']; ?>" target="_blank"><i class="fa <?php echo $abouticonn['icon']; ?>"></i></a>
	<?php endforeach; ?>
<?php endif; ?>
                    </div>
                    <div class="clear"></div>
                </div>
            <?php endif; ?>
                
            <?php if(get_post_meta(get_the_ID(), 'enable_people_2', true) == 'on'): ?>
                <div class="people_itam">
                	<div class="people_image c_right" style="background-image:url(<?php echo get_post_meta(get_the_ID(),'people_image_2', true); ?>);">
                    <?php if(get_post_meta(get_the_ID(),'people_link_2', true) != ''): ?><a href="<?php echo get_post_meta(get_the_ID(),'people_link_1', true); ?>"><?php endif; ?>
                    	<p>&nbsp;</p>
                    <?php if(get_post_meta(get_the_ID(),'people_link_2', true) != ''): ?></a><?php endif; ?>
                    </div>
                    <div class="people_info c_left">
                    	<h1><?php echo get_post_meta(get_the_ID(),'people_name_2', true); ?></h1>
                		<span><?php echo get_post_meta(get_the_ID(),'people_position_2', true); ?></span>
                        <div class="dea"></div>
<?php if(is_array(get_post_meta(get_the_ID(),'social_icon_2', true))): ?>
	<?php foreach(get_post_meta(get_the_ID(),'social_icon_2', true) as $abouticonn): ?>
                        <a href="<?php echo $abouticonn['link']; ?>" target="_blank"><i class="fa <?php echo $abouticonn['icon']; ?>"></i></a>
	<?php endforeach; ?>
<?php endif; ?>
                    </div>
                    <div class="clear"></div>
                </div>
            <?php endif; ?>
    	<div class="clear"></div>
	</div><!--.content_inner-->
    <div class="clear"></div>
</div><!--.content_area-->

<?php get_footer(); ?>      