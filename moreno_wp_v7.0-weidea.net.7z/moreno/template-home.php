<?php
/*
Template Name: Home Template
*/
get_header(); 

$tplhome_meta = array(
	'image'      => get_post_meta(get_the_ID(), 'tplhome_image', true),
	'image2x'    => get_post_meta(get_the_ID(), 'tplhome_image2x', true),
	'image_size' => get_post_meta(get_the_ID(), 'tplhome_image_size', true),
	'title'      => get_post_meta(get_the_ID(), 'tplhome_title', true),
	'subtitle'   => get_post_meta(get_the_ID(), 'tplhome_subtitle', true),
	'top_margin' => get_post_meta(get_the_ID(), 'tplhome_top_margin', true),
	'image_link' => get_post_meta(get_the_ID(), 'tplhome_image_link', true),
	'bg_color'   => get_post_meta(get_the_ID(), 'tplhome_bg_color', true),
	'bg_opacity' => get_post_meta(get_the_ID(), 'tplhome_bg_opacity', true),
	'text_color' => get_post_meta(get_the_ID(), 'tplhome_text_color', true),
	'box_style'  => get_post_meta(get_the_ID(), 'tplhome_box_style', true),
	'divider'    => get_post_meta(get_the_ID(), 'tplhome_subtitle_divider', true),
);
?>
<style type="text/css">
	<?php if($tplhome_meta['text_color'] != ''): ?>
		.home-box-warper h1 a,
		.home-box-warper{ color:<?php echo $tplhome_meta['text_color']; ?>; }
		.home-box-warper .dea{ background:<?php echo $tplhome_meta['text_color']; ?>; }
	<?php endif; ?>
	
	<?php if($tplhome_meta['bg_color'] != ''): ?>
		.home-box-warper{ background-color:rgba(<?php echo digita_hex2rgb($tplhome_meta['bg_color']); ?>, <?php echo $tplhome_meta['bg_opacity'];  ?>); }
		
		.home_hexagon:after{ border-top: 120px solid rgba(<?php echo digita_hex2rgb($tplhome_meta['bg_color']); ?>, <?php echo $tplhome_meta['bg_opacity'];  ?>); }
		.home_hexagon:before{ border-bottom: 120px solid rgba(<?php echo digita_hex2rgb($tplhome_meta['bg_color']); ?>, <?php echo $tplhome_meta['bg_opacity'];  ?>); }
	<?php endif; ?>	
	
	<?php if($tplhome_meta['top_margin'] != ''): ?>
		.home-box-warper .gap{height:<?php echo $tplhome_meta['top_margin']; ?>px !important; }
	<?php endif; ?>	
	
	<?php if($tplhome_meta['image_size'] != ''): ?>
		.home-box-warper img{ width:<?php echo $tplhome_meta['image_size']; ?>%; max-width: 100%; }
	<?php endif; ?>
</style>

<div class="front_menu"> <?php if(has_nav_menu('main_menu')){ wp_nav_menu( array('container'=>false, 'menu_id'=>'nav', 'theme_location'=>'main_menu') ); } ?></div>

<div class="home-box-warper home_<?php echo $tplhome_meta['box_style'];  ?>">
	<div class="home-box-inner">
		<div class="gap"></div>
        <?php if($tplhome_meta['box_style'] != 'image-only'): ?>
        	
            <?php if($tplhome_meta['image']): ?>
                <a href="<?php echo $tplhome_meta['image_link']; ?>">
                    <img src="<?php echo $tplhome_meta['image']; ?>" alt="<?php echo $tplhome_meta['title']; ?>" <?php if( $tplhome_meta['image2x'] != '' ){ echo 'data-at2x="'.$tplhome_meta['image2x'].'"'; } ?> />
                </a>
            <?php endif; ?>
            
            <?php if($tplhome_meta['title'] != 'n/a'): ?>
				<h1><a href="<?php echo $tplhome_meta['image_link']; ?>"><?php echo $tplhome_meta['title']; ?></a></h1>
            <?php endif; ?>
            
            <?php if($tplhome_meta['divider'] != 'no'): ?>
				<div class="dea"></div>
            <?php else: ?>
            	<div class="clear" style="height:20px;"></div>
           	<?php endif; ?>
            
            <?php if($tplhome_meta['subtitle'] != 'n/a'): ?>
                <span class="subtitle"><?php echo $tplhome_meta['subtitle']; ?></span>
            <?php endif; ?>
            
        <?php else: ?>
			<a href="<?php echo $tplhome_meta['image_link']; ?>"><img src="<?php echo $tplhome_meta['image']; ?>" alt="<?php echo $tplhome_meta['title']; ?>" /></a>
        <?php endif; ?>
	</div><!--.logo_area-->
</div>

<?php get_footer(); ?>      