<?php
include_once( get_template_directory().'/framwork/gittly/gittly.php' );
include_once(  get_template_directory().'/framwork/gittly-page/gittly-page.php' );
include_once(  get_template_directory().'/framwork/gittly-shortcodes/gittly-shortcodes.php' );
include_once(  get_template_directory().'/framwork/options/theme-options.php');

/*----------------------------------------------------------------
 ## Load JavaScript and CSS
----------------------------------------------------------------*/
new gittly_frontend_css('moreno', get_stylesheet_directory_uri().'/style.css', '');
new gittly_frontend_css('moreno-responsive', get_stylesheet_directory_uri().'/responsive.css', '');