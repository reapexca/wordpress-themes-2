<?php if ( is_active_sidebar( 'st_primary' ) ) { ?>
<!-- #sidebar -->
<aside id="sidebar" role="complementary">
<?php dynamic_sidebar( 'st_primary' )  ?>
<!-- #sidebar -->
</aside>
<?php } ?>